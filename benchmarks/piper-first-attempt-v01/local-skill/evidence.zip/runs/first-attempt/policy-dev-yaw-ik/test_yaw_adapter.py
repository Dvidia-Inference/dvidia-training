import math
import unittest

import numpy as np

from dvidia_training.piper_first_attempt_policy import _VERTICAL, _rotation
from piper_yaw_adapter import camera_twist, multiply


def camera(yaw):
    return [math.cos(yaw/2.), 0., 0., math.sin(yaw/2.)]


class YawAdapterTests(unittest.TestCase):
    def test_actual_jaw_line_matches_one_of_the_rotated_cube_diagonals(self):
        for degrees in (-89., -45., -35., -15., 0., 15., 35., 45., 69., 90.):
            yaw = math.radians(degrees)
            actual_gripper = _rotation(multiply(_VERTICAL, camera_twist(camera(yaw))))
            jaw = actual_gripper @ np.array([0., 1., 0.])
            cube_basis = _rotation(camera(yaw))
            along_cube = cube_basis.T @ jaw
            np.testing.assert_allclose(np.abs(along_cube), [2**-.5, 2**-.5, 0.], atol=1e-12)

    def test_square_symmetry_and_virtual_pose_inverse(self):
        q = np.array([.5, -.5, -.5, .5])
        for degrees in (-35, -15, 0, 15, 35):
            yaw = math.radians(degrees)
            twist = camera_twist(camera(yaw))
            np.testing.assert_allclose(twist, camera_twist(camera(yaw + math.pi/2.)), atol=1e-12)
            physical = multiply(q, twist)
            recovered = multiply(physical, twist * [1., -1., -1., -1.])
            np.testing.assert_allclose(recovered, q, atol=1e-12)

    def test_rejects_missing_or_tilted_orientation(self):
        for q in (None, [0.,0.,0.,0.], [.5,.5,.5,.5]):
            with self.assertRaises(ValueError):
                camera_twist(q)


if __name__ == '__main__':
    unittest.main()
