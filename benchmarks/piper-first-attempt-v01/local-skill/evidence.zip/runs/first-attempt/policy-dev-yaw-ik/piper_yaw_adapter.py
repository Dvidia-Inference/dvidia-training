"""Development-only camera-yaw adapter for the frozen square-corner grasp."""
import math

import numpy as np

from dvidia_training.piper_first_attempt_policy import _VERTICAL, make_policy as frozen_policy


def multiply(a, b):
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return np.array([aw*bw-ax*bx-ay*by-az*bz, aw*bx+ax*bw+ay*bz-az*by,
                     aw*by-ax*bz+ay*bw+az*bx, aw*bz+ax*by-ay*bx+az*bw])


def camera_twist(camera_wxyz):
    q = np.asarray(camera_wxyz, dtype=float)
    if (q.shape != (4,) or not np.all(np.isfinite(q)) or abs(q @ q - 1.) > 1e-6
            or np.max(np.abs(q[1:3])) > 1e-5):
        raise ValueError('A normalized, upright initial camera quaternion is required.')
    # This known cube is invariant to right-angle turns. Align the nearest
    # equivalent diagonal to the frozen nominal gripper direction.
    initial_yaw = 2. * math.atan2(q[3], q[0])
    yaw = (initial_yaw + math.pi / 4.) % (math.pi / 2.) - math.pi / 4.
    # The nominal tool points down: a positive local twist rotates the
    # parallel-jaw line clockwise in world XY at grasp time.
    return np.array([math.cos(yaw/2.), 0., 0., -math.sin(yaw/2.)])


class TwistedKinematics:
    def __init__(self, kinematics):
        self.kinematics = kinematics
        self.twist = None

    def pose_action(self, joints, point, nominal_quaternion, jaw):
        target_quaternion = multiply(nominal_quaternion, self.twist)
        return self.kinematics.pose_action(joints, point, target_quaternion, jaw)


class ImageYawCorner:
    def __init__(self, kinematics):
        self.adapter = TwistedKinematics(kinematics)
        self.underlying = frozen_policy('corner-v8', self.adapter)
        self.inverse = None

    @property
    def phase(self):
        return self.underlying.phase

    @property
    def refusal_reason(self):
        return self.underlying.refusal_reason

    def __call__(self, observation):
        if self.inverse is None:
            self.adapter.twist = camera_twist(observation['initial_object_quaternion_world_wxyz'])
            self.inverse = self.adapter.twist * [1., -1., -1., -1.]
        # Express measured orientation in the same nominal tool frame that
        # the frozen policy uses for alignment and its held-offset estimate.
        local = dict(observation)
        local['tcp_quaternion_wxyz'] = multiply(observation['tcp_quaternion_wxyz'], self.inverse)
        return self.underlying(local)


class ReachableImageYawCorner(ImageYawCorner):
    """Choose an equivalent cube diagonal using static PiPER kinematics."""

    def __call__(self, observation):
        if self.inverse is None:
            base = camera_twist(observation['initial_object_quaternion_world_wxyz'])
            q = np.asarray(observation['joint_position_rad'])
            pregrasp = np.asarray(observation['initial_object_position_world_m']).copy()
            pregrasp[2] = observation['goal_position_world_m'][2] + .034
            candidates = []
            for quarter_turns in (0, -1, 1, -2):
                a = quarter_turns * math.pi / 4.
                twist = multiply(base, [math.cos(a), 0., 0., math.sin(a)])
                target = multiply(_VERTICAL, twist)
                planned = q.copy()
                for _ in range(120):
                    action = self.adapter.kinematics.pose_action(planned, pregrasp, target, .035)
                    updated = np.asarray(action['joint_targets_rad'])
                    if np.max(np.abs(updated-planned)) < .00005:
                        break
                    planned = updated
                pose = self.adapter.kinematics.fk(planned)
                position_error = np.linalg.norm(np.asarray(pose['tcp_position_world_m'])-pregrasp)
                angle = 2.*math.acos(np.clip(abs(np.dot(pose['tcp_quaternion_world_wxyz'],target)),0.,1.))
                if position_error < .008 and angle < .12:
                    distance = np.abs(q-planned)
                    # Longest joint travel bounds free-space execution time.
                    # Sum breaks ties in favor of smaller total motion.
                    cost = float(np.max(distance) + .10*np.sum(distance))
                    candidates.append((cost, len(candidates), twist))
            if not candidates:
                raise ValueError('No robot-only IK solution for the four equivalent pregrasps')
            _, _, self.adapter.twist = min(candidates, key=lambda row: row[:2])
            self.inverse = self.adapter.twist * [1., -1., -1., -1.]
        return super().__call__(observation)


def make_policy(name, kinematics):
    if name == 'image-yaw-reachable':
        return ReachableImageYawCorner(kinematics)
    raise ValueError('Unknown yaw diagnostic policy.')
