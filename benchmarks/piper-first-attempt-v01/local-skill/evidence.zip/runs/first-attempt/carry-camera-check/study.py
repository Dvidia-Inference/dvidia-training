"""Development diagnostic rejecting visibly detached cube surfaces at 10 Hz."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import time
import zlib

import numpy as np

from dvidia_training import camera_action_capture as capture
from dvidia_training import piper_first_attempt_eval as evaluation
from dvidia_training import piper_rgbd_tracker as tracker
from dvidia_training.piper_encoder_kinematics import PiperEncoderKinematics
from dvidia_training.piper_feedback_env import FeedbackPiperTaskEnv, JawPulse
from dvidia_training.piper_workspace_calibration import load_workspace_calibration


def digest(p):
    return sha256(p.read_bytes()).hexdigest()


def write(p,d):
    with p.open('x') as f:
        json.dump(d,f,indent=2,sort_keys=True,allow_nan=False)
        f.write('\n')


def surface_distance(rgb, depth, calibration, now, tcp):
    cfg=tracker.TrackerConfig()
    intrinsics,transform=tracker._calibration(calibration,depth.shape,now,now)
    red,green,blue=(channel.astype(np.float32) for channel in np.moveaxis(rgb,-1,0))
    mask=((red>=cfg.minimum_red_intensity)&(green>=cfg.minimum_green_intensity)
         &(red>=green*1.35)&(red>=blue*1.8)&(green>=blue*1.15))
    if mask.sum()>cfg.maximum_colour_pixels:
        return None,'colour_support_exceeds_profile'
    candidates=[p for p in tracker._components(mask) if len(p)>=cfg.minimum_component_pixels]
    if len(candidates)!=1:
        return None,'absent_or_ambiguous_component'
    rows,columns=candidates[0].T; height,width=depth.shape
    if np.any(rows==0) or np.any(rows==height-1) or np.any(columns==0) or np.any(columns==width-1):
        return None,'cropped_component'
    z=depth[rows,columns].astype(float)
    if (not np.isfinite(z).all() or np.any(z<cfg.minimum_depth_m) or np.any(z>cfg.maximum_depth_m)):
        return None,'invalid_depth'
    fx,fy,cx,cy=intrinsics
    optical=np.stack(((columns+.5-cx)*z/fx,(rows+.5-cy)*z/fy,z),axis=-1)
    points=optical@transform[:3,:3].T+transform[:3,3]
    return float(np.percentile(np.linalg.norm(points-tcp,axis=1),10)),'available'


def earliest(a,b):
    values=[x for x in (a,b) if x is not None]
    return min(values) if values else None


def check(args,previous,enabled,calibration,kinematics):
    source=args.source/(previous['case_id']+'-learned.json')
    receipt=json.loads(source.read_text());case=receipt['case']
    binding=receipt['action_log']
    name=Path(binding['path'])
    if name.name!=str(name):
        raise ValueError('Unsafe action log path')
    actions_path=source.parent/name
    if actions_path.stat().st_size>65536 or digest(actions_path)!=binding['sha256']:
        raise ValueError('Action tape digest mismatch')
    raw=zlib.decompress(actions_path.read_bytes())
    if len(raw)!=56000:
        raise ValueError('Invalid action tape length')
    actions=np.frombuffer(raw,dtype='<f8').reshape(1000,7)
    pulse=previous['pulse']
    class Scheduled(evaluation._MaterialSession):
        def _environment(self,task):
            scheduled=() if pulse is None else (JawPulse(*pulse),)
            return FeedbackPiperTaskEnv(self.assets,self.task_config,pulses=scheduled)
    session=Scheduled(args.assets,capture.RolloutConfig(duration_s=20.,seed=case['seed']),case)
    rows=[];alarm=None
    try:
        session.open()
        for i,action in enumerate(actions):
            if 475<=i<=650 and (i-475)%5==0:
                now=float(session.env.elapsed)
                if abs(now-i*.02)>1e-8:
                    raise ValueError('Control clock drift')
                _,_,_,timing=session.sample(len(rows))
                rgb,depth=session.latest_rgbd
                tcp=np.asarray(kinematics.fk(session.env.data.qpos[:6].tolist())['tcp_position_world_m'])
                start=time.perf_counter()
                distance,status=surface_distance(rgb,depth,calibration,now,tcp)
                elapsed=time.perf_counter()-start
                start=time.perf_counter()
                pose=tracker.estimate_pose(rgb,depth,calibration,frame_index=len(rows),captured_at_seconds=now,
                    available_at_seconds=now,decision_at_seconds=now)
                tracker_time=time.perf_counter()-start
                active=bool(enabled[case['goal_id'],i])
                if active and alarm is None and distance is not None and distance>.055:
                    alarm=now
                rows.append(dict(sim_s=now,surface_status=status,tenth_percentile_tcp_distance_m=distance,
                    eligible=active,pose_status=pose['status'],pose_reason=pose['reason'],
                    render_encode_ms=timing['render_encode_wall_seconds']*1000.,
                    surface_check_ms=elapsed*1000.,full_tracker_ms=tracker_time*1000.))
            session.advance({'joint_targets_rad':action[:6].tolist(),'gripper_position_m':float(action[6])})
        if bool(session.info['success'])!=previous['strict_success'] or int(session.env.critical_contact_ticks)!=previous['critical_ticks']:
            raise ValueError('Matched native physics disagrees with prior replay')
        warnings=sorted(set(session.renderer_warnings))
        known='ARB_clip_control unavailable while mjDEPTH_ZEROFAR requested, depth accuracy will be limited'
        if any(message!=known for message in warnings):
            raise RuntimeError('Unexpected native renderer warning: '+repr(warnings))
    finally:
        session.close()
    encoder=previous['outputs']['learned']['first_warning_s']
    return dict(case_id=case['id'],pulse=pulse,native_loss_s=previous['retention_loss_confirmed_s'],
        strict_success=previous['strict_success'],renderer_warnings=warnings,encoder_first_warning_s=encoder,
        camera_first_warning_s=alarm,either_first_warning_s=earliest(encoder,alarm),frames=rows)


def main():
    cli=argparse.ArgumentParser()
    for name in ('assets','calibration','source','monitor','plan','output'):
        cli.add_argument('--'+name,type=Path,required=True)
    args=cli.parse_args()
    plan=json.loads(args.plan.read_text())
    result_path=args.monitor/'results.json';model_path=args.monitor/'finger-envelope.npz'
    if digest(result_path)!=plan['matched_detector_results_sha256'] or digest(model_path)!=plan['expected_grip_model_sha256']:
        raise ValueError('Registered detector evidence changed')
    attempts=json.loads(result_path.read_text())['attempts']
    enabled=np.load(model_path,allow_pickle=False)['enabled']
    calibration=load_workspace_calibration(args.calibration,duration_s=20.)
    kinematics=PiperEncoderKinematics(args.assets)
    args.output.mkdir(exist_ok=False)
    for idx,previous in enumerate(attempts):
        result=check(args,previous,enabled,calibration,kinematics)
        write(args.output/f'attempt-{idx:02}.json',result)
        print(result['case_id'],result['pulse'],result['camera_first_warning_s'],result['native_loss_s'],flush=True)
    write(args.output/'index.json',dict(plan_sha256=digest(args.plan),driver_sha256=digest(Path(__file__)),
        calibration_sha256=digest(args.calibration),attempts=len(attempts)))


if __name__=='__main__':
    main()
