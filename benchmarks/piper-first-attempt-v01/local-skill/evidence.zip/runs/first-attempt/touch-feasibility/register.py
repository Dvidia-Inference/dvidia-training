"""Write the split and model protocol before reading any rollout outcomes."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path

directory = Path(__file__).resolve().parent
source = directory.parent / 'corner-load-envelope'
roster_path = source / 'roster.json'
roster = json.loads(roster_path.read_text())
mass = sorted({r['mass_kg'] for r in roster})
friction = sorted({r['friction'] for r in roster})
assert len(mass) == 5 and len(friction) == 4 and len(roster) == 40
split = {'train': [], 'test': []}
for r in roster:
    side = 'train' if (mass.index(r['mass_kg']) + friction.index(r['friction'])) % 2 == 0 else 'test'
    split[side].append(r['id'])
assert all(len(v) == 20 for v in split.values())
plan = dict(
    schema='dvidia.piper-touch-feasibility-study/v1', registered_utc=datetime.now(timezone.utc).isoformat(),
    scope='Supplemental retrospective simulator development diagnostic. A fixed split/feature fit of existing controlled-load trials; no confirmation, model tuning, replacements or physical sensor claims.',
    roster_sha256=sha256(roster_path.read_bytes()).hexdigest(), split_rule='Sorted zero-based mass index plus sorted friction index. Even cells train; odd cells test. Both starts stay inside one split.',
    case_ids=split, mass_kg=mass, friction=friction,
    trigger='First recorded commanded gripper target below .0175 m. Measured t0 is the pre-action encoder snapshot for that command.',
    observation_clock_s=.02, prefix_s=1.32, probe_start_s=.72, tail_s=.10,
    feature_inputs='Measured six arm and two signed finger positions and velocities, latest previously applied arm actuator target, detached robot-only FK/Jacobian. No native object/contact/force, mass/friction, initial camera, timestamp-to-close, scene identity, later measurements or task phase.',
    prefix_features=[
        'change in mean signed aperture half-span from +.72 to +1.32 s',
        'mean signed aperture velocity over final .10 s inclusive',
        'change in absolute signed finger asymmetry from +.72 to +1.32 s',
        'vertical tool displacement from +.72 to +1.32 s by encoder FK',
        'mean vertical tool velocity over final .10 s inclusive by encoder Jacobian and velocity',
        'change in arm joint RMS applied-target tracking error from +.72 to +1.32 s',
    ],
    baseline_features=[
        'pre-close mean signed aperture half-span',
        'pre-close signed aperture velocity',
        'pre-close absolute signed finger asymmetry',
        'pre-close absolute signed finger asymmetry velocity',
        'pre-close vertical TCP velocity by encoder Jacobian and velocity',
        'pre-close RMS arm tracking error against previously applied target',
    ],
    fit='Standardized logistic regression with training-only population mean/SD, setting SD <1e-9 to one. Minimize summed Bernoulli negative log likelihood and L2 penalty 0.5*||w||², no intercept penalty. Predetermined Newton solver, 40 iterations max and step convergence tolerance 1e-10. Probability >= 0.5 predicts feasible. One estimator each for prefix and pre-close baseline. No coefficient adjustment after seeing test.',
    ideal_known_material_bound='Privileged diagnostic only. mu * (40 N/m) * (0.02 m * sqrt(2)) >= mass * 9.81 m/s². Descriptive static proxy, excluded from both learned policies.',
    label='Validated native independent sustained bilateral table-free lift of 60 mm for 100 ms, exactly reproducing piper_feedback_score and earlier receipt. Scoring consumes native physics, never model features.',
    audits='Headless exact replay of all 40 recorded action tapes. Check closed prefix and no shared material cell or episode between split. Measure lead from cutoff to first native 60 mm crossing and first 100 ms sustained lift, report whether any test window already passed physical target distance. Report all class counts, confusion, false feasible, balanced accuracy, wall fit and microbenchmark policy prediction latency separately from FK and acquisition.',
)
with (directory / 'protocol.json').open('x') as stream:
    json.dump(plan, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(sha256((directory/'protocol.json').read_bytes()).hexdigest())
