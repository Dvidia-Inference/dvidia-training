"""Replay exact tapes and isolate a fixed causal encoder feature prefix."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from time import perf_counter
from unittest.mock import patch

import numpy as np

from dvidia_training import piper_first_attempt_replay as native_replay
from dvidia_training.piper_encoder_kinematics import PiperEncoderKinematics


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def native_label(arrays, start_height, cutoff_s):
    times = arrays['t_seconds']
    height = arrays['object_position_m'][:, 2] - start_height
    crossing = np.flatnonzero(height >= .06)
    bilateral = np.all(arrays['grasp_contact_counts'] > 0, axis=1)
    table_free = arrays['table_object_contact_count'] == 0
    mask = (height >= .06) & bilateral & table_free
    sustained_starts = np.flatnonzero(np.convolve(mask.astype(int), np.ones(100, dtype=int), mode='valid') == 100)
    before_decision = times <= cutoff_s + 1e-9
    return dict(
        sustained_lift_label=bool(len(sustained_starts)),
        first_60mm_native_s=float(times[crossing[0]]) if len(crossing) else None,
        first_sustained_lift_native_s=float(times[sustained_starts[0] + 99]) if len(sustained_starts) else None,
        lift_already_60mm=bool(np.any(before_decision & (height >= .06))),
        max_predecision_native_lift_m=float(np.max(height[before_decision])),
    )


def read_encoders(state, previously_applied):
    """Read only the publicly meaningful encoder and applied-target channels."""
    positions = state.qpos[:8].copy()
    velocities = state.qvel[:8].copy()
    return positions, velocities, previously_applied.copy()


def kinematic_channels(kin, measured):
    positions, velocity, applied = measured
    q, q_velocity = positions[:6], velocity[:6]
    left, right = positions[6], -positions[7]
    left_rate, right_rate = velocity[6], -velocity[7]
    return dict(
        aperture=.5 * (left + right),
        aperture_velocity=.5 * (left_rate + right_rate),
        skew=abs(left - right),
        skew_velocity=abs(left_rate - right_rate),
        tool_z=kin.fk(q)['tcp_position_world_m'][2],
        tool_z_velocity=float(kin.jacobian(q)[2] @ q_velocity),
        tracking_error=float(np.sqrt(np.mean((q - applied) ** 2))),
    )


def assemble_features(channels, start, probe, end, tail_steps):
    before, during, last = channels[start], channels[probe], channels[end]
    tail = [channels[index] for index in range(end - tail_steps, end + 1)]
    return dict(
        preclose=[before[name] for name in (
            'aperture', 'aperture_velocity', 'skew', 'skew_velocity',
            'tool_z_velocity', 'tracking_error')],
        prefix=[
            last['aperture'] - during['aperture'],
            float(np.mean([row['aperture_velocity'] for row in tail])),
            last['skew'] - during['skew'],
            last['tool_z'] - during['tool_z'],
            float(np.mean([row['tool_z_velocity'] for row in tail])),
            last['tracking_error'] - during['tracking_error'],
        ],
    )


def analyze_episode(assets, case, path, plan, kin):
    receipt = json.loads(path.read_text())
    if receipt['case']['id'] != case['id'] or not receipt['valid'] or receipt['status'] != 'completed':
        raise ValueError(f'Expected a completed native-valid teacher trial for {case["id"]}.')
    targets = native_replay.read_actions(path.parent, receipt['action_log'])
    closing = np.flatnonzero(targets[:, 6] < .0175)
    if not len(closing):
        raise ValueError('No commanded close in exact native tape.')
    dt = plan['observation_clock_s']
    first = int(closing[0])
    probe = first + round(plan['probe_start_s'] / dt)
    end = first + round(plan['prefix_s'] / dt)
    tail = round(plan['tail_s'] / dt)
    sample_indices = {first, probe, *range(end - tail, end + 1)}
    measurements = {}
    timings = {}
    label = {}
    original_env = native_replay.FeedbackPiperTaskEnv

    class EncoderCapture(original_env):
        def step(self, action):
            index = self.steps
            if index in sample_indices:
                measurements[index] = read_encoders(self.data, self.data.ctrl[:6])
                timings[index] = float(self.elapsed)
            return super().step(action)

        def native_arrays(self):
            values = super().native_arrays()
            label.update(native_label(values, float(self.initial_object_position[2]), timings[end]))
            return values

    with patch.object(native_replay, 'FeedbackPiperTaskEnv', EncoderCapture):
        check = native_replay.replay(assets, path)
    if not check['reproduced']:
        raise ValueError(f'Native replay mismatch for {case["id"]}: {check["mismatches"]}.')
    expected_label = receipt['score']['native_recomputed']['lift_seen']
    if type(expected_label) is not bool or label['sustained_lift_label'] != expected_label:
        raise ValueError('Independent sustained lift differs from the original scorer.')
    if set(measurements) != sample_indices or abs(timings[end] - timings[first] - plan['prefix_s']) > 1e-8:
        raise ValueError('Encoder history differs from the registered causal window.')
    began = perf_counter()
    channels = {index: kinematic_channels(kin, values) for index, values in measurements.items()}
    features = assemble_features(channels, first, probe, end, tail)
    compute = perf_counter() - began
    return dict(
        case_id=case['id'], source_receipt_sha256=check['receipt_sha256'],
        logged_action_sha256=receipt['action_log']['sha256'],
        taken_sample_indices=sorted(measurements), close_time_s=timings[first],
        decision_time_s=timings[end], feature_compute_wall_ms=1000 * compute,
        features=features, diagnostics=label,
    )


def main():
    cli = ArgumentParser(description=__doc__)
    for field in ('plan', 'roster', 'receipts', 'assets', 'output'):
        cli.add_argument('--'+field, type=Path, required=True)
    args = cli.parse_args()
    plan = json.loads(args.plan.read_text())
    if digest(args.roster) != plan['roster_sha256']:
        raise ValueError('Source roster differs from preregistration.')
    cases = json.loads(args.roster.read_text())
    if len(cases) != 40:
        raise ValueError('Expected all 40 registered load trials.')
    kin = PiperEncoderKinematics(args.assets)
    rows = []
    args.output.mkdir(exist_ok=False)
    for index, case in enumerate(cases):
        path = args.receipts / f'attempt-{index:04}.json'
        result = analyze_episode(args.assets, case, path, plan, kin)
        with (args.output / f'features-{index:04}.json').open('x') as stream:
            json.dump(result, stream, sort_keys=True, indent=2, allow_nan=False)
            stream.write('\n')
        rows.append(result)
        print(case['id'], 'reproduced', flush=True)
    receipt = dict(plan_sha256=digest(args.plan), extract_source_sha256=digest(__file__), attempts=rows)
    with (args.output / 'features.json').open('x') as stream:
        json.dump(receipt, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


if __name__ == '__main__':
    main()
