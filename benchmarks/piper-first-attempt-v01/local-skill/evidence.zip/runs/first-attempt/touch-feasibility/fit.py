"""Train the fixed touch-feasibility diagnostics and score held-out material cells."""
from argparse import ArgumentParser
from hashlib import sha256
import json
import math
from pathlib import Path
from statistics import median
from time import perf_counter, perf_counter_ns

import numpy as np


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def sigmoid(logit):
    return 1. / (1. + np.exp(-np.clip(logit, -50., 50.)))


class Logistic:
    def __init__(self, x, y):
        if x.shape != (20, 6) or y.shape != (20,) or len(np.unique(y)) != 2:
            raise ValueError('Require both classes in the 20-case, six-feature training data.')
        self.center = x.mean(axis=0)
        scale = x.std(axis=0)
        self.scale = np.where(scale >= 1e-9, scale, 1.)
        design = np.column_stack((np.ones(len(y)), (x - self.center) / self.scale))
        penalty = np.diag([0.] + [1.] * x.shape[1])
        self.coefficients = np.zeros(design.shape[1])
        for self.iterations in range(1, 41):
            p = sigmoid(design @ self.coefficients)
            gradient = design.T @ (p - y) + penalty @ self.coefficients
            hessian = (design.T * (p * (1. - p))) @ design + penalty
            step = np.linalg.solve(hessian, gradient)
            self.coefficients -= step
            if np.max(np.abs(step)) <= 1e-10:
                break
        else:
            raise ValueError('The registered optimizer did not converge.')

    def predict(self, x):
        bias, coefficients = self.coefficients[0], self.coefficients[1:]
        return sigmoid((x - self.center) / self.scale @ coefficients + bias)

    def parameters(self):
        return dict(center=self.center.tolist(), scale=self.scale.tolist(),
                    intercept=float(self.coefficients[0]), coefficients=self.coefficients[1:].tolist(),
                    iterations=self.iterations)


def confusion(y, predicted):
    y = np.asarray(y, dtype=bool)
    predicted = np.asarray(predicted, dtype=bool)
    tp = int(np.count_nonzero(y & predicted))
    tn = int(np.count_nonzero(~y & ~predicted))
    fn = int(np.count_nonzero(y & ~predicted))
    fp = int(np.count_nonzero(~y & predicted))
    positives, negatives = tp + fn, tn + fp
    return dict(positives=positives, negatives=negatives, true_feasible=tp, true_infeasible=tn,
        missed_feasible=fn, false_feasible=fp, predicted_feasible=tp + fp, accuracy=(tp + tn) / len(y),
        false_feasible_rate=fp / negatives,
        false_feasible_among_feasible_predictions=fp / (tp + fp) if tp + fp else None,
        balanced_accuracy=.5 * (tp / positives + tn / negatives))


def fit_scored(train, test, feature_name, labels):
    x = np.array([row['features'][feature_name] for row in train])
    y = np.array([row['diagnostics']['sustained_lift_label'] for row in train], dtype=float)
    if not np.isfinite(x).all():
        raise ValueError('Nonfinite registered training feature.')
    began = perf_counter()
    model = Logistic(x, y)
    fit_ms = (perf_counter() - began) * 1000
    test_x = np.array([row['features'][feature_name] for row in test])
    case_probabilities = model.predict(test_x)
    predictions = case_probabilities >= .5
    repeated = []
    for iteration in range(2000):
        sample = test_x[iteration % len(test_x)]
        began_ns = perf_counter_ns()
        model.predict(sample)
        repeated.append((perf_counter_ns() - began_ns) / 1000)
    paper = dict(
        **confusion(labels, predictions), fit_ms=fit_ms, model=model.parameters(),
        prediction_wall_us_median=median(repeated), prediction_wall_us_p95=float(np.percentile(repeated, 95)),
        latency_scope='CPU scaler, dot product and sigmoid for one precomputed six-feature vector. Excludes acquisition and FK.',
    )
    return paper, case_probabilities.tolist(), predictions.tolist()


def timing(row):
    packed = row['diagnostics']
    cutoff = row['decision_time_s']
    first = packed['first_60mm_native_s']
    sustained = packed['first_sustained_lift_native_s']
    return dict(
        first_60mm_minus_decision_s=None if first is None else first - cutoff,
        first_sustained_lift_minus_decision_s=None if sustained is None else sustained - cutoff,
        **packed,
    )


def main():
    cli = ArgumentParser(description=__doc__)
    for field in ('plan', 'roster', 'features', 'output'):
        cli.add_argument('--' + field, type=Path, required=True)
    args = cli.parse_args()
    plan = json.loads(args.plan.read_text())
    extracted = json.loads(args.features.read_text())
    if digest(args.roster) != plan['roster_sha256'] or digest(args.plan) != extracted['plan_sha256']:
        raise ValueError('Feature receipt, roster and plan digests conflict.')
    cases = {row['id']: row for row in json.loads(args.roster.read_text())}
    names = plan['case_ids']
    names_train, names_test = (names[key] for key in ('train', 'test'))
    if len(set(names_train) | set(names_test)) != 40 or set(names_train) & set(names_test):
        raise ValueError('The registered split is not disjoint.')
    cells = {key: {(cases[name]['mass_kg'], cases[name]['friction']) for name in group}
             for key, group in names.items()}
    if len(cells['train']) != 10 or len(cells['test']) != 10 or cells['train'] & cells['test']:
        raise ValueError('The registered split leaks mass/friction cells.')
    trials = {row['case_id']: row for row in extracted['attempts']}
    if len(extracted['attempts']) != 40 or set(trials) != set(cases):
        raise ValueError('The replay must cover all planned cases.')
    for row in trials.values():
        expected = round(row['decision_time_s'] / .02)
        if row['taken_sample_indices'][-1] != expected or abs(row['decision_time_s'] - row['close_time_s'] - 1.32) > 1e-8:
            raise ValueError('Feature timestamp audit failed.')
        if not np.isfinite(np.asarray(list(row['features'].values()))).all():
            raise ValueError('Nonfinite registered features.')
    train, test = ([trials[case] for case in names[key]] for key in ('train', 'test'))
    labels = [row['diagnostics']['sustained_lift_label'] for row in test]
    prefix, prefix_p, prefix_predict = fit_scored(train, test, 'prefix', labels)
    baseline, baseline_p, baseline_predict = fit_scored(train, test, 'preclose', labels)
    margins = [cases[name]['friction'] * 40. * .020 * math.sqrt(2.) / (9.81 * cases[name]['mass_kg'])
               for name in names_test]
    ideal_predict = [ratio >= 1. for ratio in margins]
    rows = [dict(
        case_id=name, label=truth, prefix_probability=pp, preclose_probability=bp,
        prefix_prediction=phat, preclose_prediction=bhat,
        privileged_static_margin_ratio=margin, privileged_static_prediction=ideal,
        decision_time_s=trials[name]['decision_time_s'], close_time_s=trials[name]['close_time_s'],
        **timing(trials[name]))
        for name, truth, pp, bp, phat, bhat, margin, ideal in zip(
            names_test, labels, prefix_p, baseline_p, prefix_predict, baseline_predict, margins, ideal_predict, strict=True)]
    leads = [r['first_60mm_minus_decision_s'] for r in rows if r['first_60mm_minus_decision_s'] is not None]
    sustained_leads = [r['first_sustained_lift_minus_decision_s'] for r in rows if r['label']]
    feature_cost = [row['feature_compute_wall_ms'] for row in test]
    valid_forecast = not any(row['lift_already_60mm'] for row in rows)
    results = dict(
        scope='retrospective development-only simulation, held-out checkerboard material cells',
        forecast_chronology_valid=valid_forecast,
        protocol_sha256=digest(args.plan), feature_receipt_sha256=digest(args.features),
        fit_source_sha256=digest(__file__), train_cells=sorted(cells['train']), test_cells=sorted(cells['test']),
        train_count=len(train), train_positives=sum(r['diagnostics']['sustained_lift_label'] for r in train),
        train_negatives=sum(not r['diagnostics']['sustained_lift_label'] for r in train), test_count=len(test),
        independent_exact_replays=len(trials), prefix=prefix, preclose=baseline,
        privileged_static=confusion(labels, ideal_predict),
        median_feature_compute_wall_ms=median(feature_cost),
        lead_s_to_first_60mm=dict(min=min(leads), median=median(leads), max=max(leads)) if leads else None,
        lead_s_to_sustained_lift=dict(min=min(sustained_leads), median=median(sustained_leads), max=max(sustained_leads))
        if sustained_leads else None,
        maximum_native_lift_predecision_m=max(r['max_predecision_native_lift_m'] for r in rows),
        case_rows=rows,
    )
    with args.output.open('x') as stream:
        json.dump(results, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')
    for name in ('prefix', 'preclose', 'privileged_static'):
        print(name, {key: results[name][key] for key in ('positives', 'negatives', 'true_feasible',
            'true_infeasible', 'false_feasible', 'missed_feasible', 'balanced_accuracy')})
    print('chronology', valid_forecast, 'first 60 mm leads', results['lead_s_to_first_60mm'])


if __name__ == '__main__':
    main()
