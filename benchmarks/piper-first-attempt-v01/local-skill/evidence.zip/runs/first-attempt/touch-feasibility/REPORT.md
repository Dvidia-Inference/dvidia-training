# Does a short test lift predict a sustained lift?

A classifier using the last part of a **1.32 s close-and-test-lift sequence** correctly forecast sustained lifting on **17/20 held-out simulator episodes**, compared with **11/20** from a pre-close encoder snapshot. It identified six additional feasible lifts. Both classifiers still overestimated the same two infeasible episodes.

## Held-out results

| Simulated measure | Pre-close encoders | Test-lift encoders | Static bound with true material |
|---|---:|---:|---:|
| Correct feasible predictions | 7/14 | 13/14 | 14/14 |
| Correct infeasible predictions | 4/6 | 4/6 | 4/6 |
| Infeasible episodes predicted feasible | 2/6 | 2/6 | 2/6 |
| Feasible episodes predicted infeasible | 7/14 | 1/14 | 0/14 |
| Overall accuracy | 55% | 85% | 90% |
| Balanced accuracy | 58.33% | 79.76% | 83.33% |

Both false-feasible outcomes were the 40 g, friction 0.35 condition, tested at both starting positions. Its ideal static margin was approximately 1.009 times the object's weight. The test-lift classifier missed one successful lift at 85 g and friction 0.95. A brief lift signal improved feasibility detection in this setup, while the two false-feasible trials prevent treating its output as permission to proceed.

## How the test was scored

The prior load sweep covered 20 mass–friction combinations with two starts per combination. A preregistered checkerboard split assigned 10 entire combinations and their 20 episodes to each partition, with no shared material combination. Training contained 12 feasible and eight infeasible episodes. Testing contained 14 feasible and six infeasible episodes. Both physical starts were reused across different material combinations.

The six-signal classifier used signed finger aperture change and speed, finger asymmetry change, vertical TCP displacement and speed from encoder kinematics, and change in arm tracking error against prior applied targets. The earliest snapshot was immediately before the first close command. The decision snapshot was 66 intervals later at 50 Hz. The model did not receive the block mass, friction, contact states, pad force, scene ID or later observations. Scaling and linear-logistic coefficients used the 20 training episodes only. Both classifiers used the same fixed regularization and probability cutoff. The known-material bound is a separate diagnostic with access to the simulator constructor values.

Headless replay reproduced all 40 exact native command streams and outcomes. The independent label required bilateral, table-free lifting of at least 60 mm for 100 ms. The largest observed native block displacement before the test decision was 6.05 mm, and no held-out block had crossed 60 mm by that time. Native 60 mm crossings followed the classifier cutoff by 0.732–0.752 simulated seconds, with a 0.7415 s median. The sustained-lift requirement was confirmed 0.831–0.851 s after the cutoff.

On one arm64 Mac, the prefix scaler, dot product and sigmoid took a median 1.88 μs and p95 2.00 μs for already-computed features. Encoder feature calculation including detached FK/Jacobian took 0.213 ms median in offline replay. The prefix fit took 3.41 ms. These timings are separate from the 1.32 simulated seconds of interaction, acquisition and actual robot response. Some distinguishing aperture changes were tens of micrometres. Physical encoders, transmission tolerances and dynamics would require separate validation.

## Reproduce

Run in the worktree with the existing NumPy and MuJoCo Python environment and pinned PiPER assets. Use fresh output paths.

```sh
study=runs/first-attempt/touch-feasibility
source=runs/first-attempt/corner-load-envelope

PYTHONPATH=src python "$study/extract.py" --plan "$study/protocol.json" \
  --roster "$source/roster.json" --receipts "$source/receipts" \
  --assets "$PIPER_ASSETS" --output "$study/replay-reproduction"

python "$study/fit.py" --plan "$study/protocol.json" --roster "$source/roster.json" \
  --features "$study/replay-reproduction/features.json" --output "$study/results-reproduction.json"
```

[Preregistered protocol](protocol.json) · [Test results and fitted parameters](results.json) · [Encoder feature and replay receipts](replay/features.json)
