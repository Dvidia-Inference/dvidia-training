"""Check packaged NumPy outputs against all reported learned actuator tapes."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import zlib

import numpy as np

from dvidia_training.piper_feedback_env import FeedbackPiperTaskEnv
from dvidia_training.piper_task import PiperTaskConfig
from policy import Policy


ROOT = Path(__file__).resolve().parent


def verify_manifest():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    for relative, digest in manifest['members_sha256'].items():
        if sha256((ROOT / relative).read_bytes()).hexdigest() != digest:
            raise ValueError(f'Manifest mismatch for {relative}.')
    return len(manifest['members_sha256'])


def compare(assets, receipt):
    case = receipt['case']
    env = FeedbackPiperTaskEnv(assets, PiperTaskConfig(
        timeout_s=20., object_position_m=case['object_position_m'],
        target_position_m=case['goal_position_m'], mass_kg=case['mass_kg'],
        friction=case['friction']))
    state, info = env.reset(case['seed'])
    binding = receipt['action_log']
    compressed = (ROOT / 'development' / binding['path']).read_bytes()
    if sha256(compressed).hexdigest() != binding['sha256']:
        raise ValueError('Actuator tape changed.')
    expected = np.frombuffer(zlib.decompress(compressed), dtype='<f8').reshape(1000, 7)
    policy = Policy(ROOT / 'model/camera-xy-primitive.npz')
    largest_error = 0.
    for reference in expected:
        observed = policy(dict(
            t_seconds=env.elapsed, joint_position_rad=state['joint_position_rad'],
            initial_object_position_world_m=receipt['initial_tracker']['object_position_world_m'],
            goal_position_world_m=case['goal_position_m'],
        ))
        predicted = np.asarray([*observed['joint_targets_rad'], observed['gripper_position_m']])
        largest_error = max(largest_error, float(np.max(np.abs(reference - predicted))))
        # Use the recorded trajectory to keep the encoder comparison fixed.
        state, info = env.step(dict(joint_targets_rad=reference[:6].tolist(),
                                    gripper_position_m=float(reference[6])))
        if not info['valid']:
            raise ValueError('Native replay became invalid.')
    return dict(case_id=case['id'], max_absolute_difference=largest_error,
                exact_actions=largest_error == 0.)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--assets', type=Path, required=True)
    args = parser.parse_args()
    count = verify_manifest()
    receipts = sorted((ROOT / 'development').glob('development-*-learned.json'))
    comparisons = [compare(args.assets, json.loads(p.read_text())) for p in receipts]
    if len(comparisons) != 12:
        raise ValueError('Expected all twelve exact model command tapes.')
    result = dict(manifest_members_verified=count, comparisons=comparisons,
                  reproduced=sum(row['exact_actions'] for row in comparisons))
    print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
    return int(result['reproduced'] != 12)


if __name__ == '__main__':
    raise SystemExit(main())
