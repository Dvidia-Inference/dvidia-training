# Demonstration data card

The training set contains 32 synthetic demonstrations. A frozen authored PiPER controller used one surveyed 320×240 RGB-D frame to locate an upright 40 mm block. It used 50 Hz robot encoders, robot-only forward kinematics and signed gripper aperture to complete the placement. All 32 attempts satisfied the independent strict scorer.

- 16 XY positions in a preregistered 4×4 lattice.
- Two destinations per XY with both episodes in the same group.
- Three predefined mass and friction combinations. Those values configure simulation and are absent from the fitted feature set.
- 1,000 decisions per episode at 50 Hz, covering 20 seconds of simulated time. Native physics checks operate on a separate 1 ms clock.
- Historical camera XY, destination and elapsed time condition the fit. The seven labels are the issued targets from the authored simulator controller.

Each tape contains `(1000, 7)` little-endian float64 values compressed with zlib. The first six values per row are joint targets in radians. The seventh is the single-finger target in metres. The paired receipt binds the tape digest, initial camera estimate, setup calibration, native environment and strict outcome. The first RGB-D delivery is represented by its receipt and frame hashes. The bundle carries no RGB-D pixel arrays, real footage or physical telemetry.

The model was evaluated on 12 pre-existing development scenes from six different XY positions. Their scene IDs and the roster hash were registered before collection. These trials were held out of model fitting. They were part of earlier teacher development and remain development evidence.

Use [the registered protocol](protocol.json), [the training index](model/demonstrations.json), [the training roster](training-cases.json) and [the exact teacher tapes](teacher).
