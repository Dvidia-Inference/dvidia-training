"""Assemble a deterministic allowlisted archive for the local experiment."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


study = Path(__file__).resolve().parent
root = study.parents[2]
benchmark = root / 'benchmarks/piper-first-attempt-v01'
source = root / 'src/dvidia_training'
files = {}


def add(path, location=None):
    name = location or path.relative_to(study).as_posix()
    files[name] = path.read_bytes()


for name in ('BUNDLE.md', 'MODEL_CARD.md', 'DATA_CARD.md', 'REPORT.md', 'LICENSE',
             'policy.py', 'verify_bundle.py', 'verify_replay.py', 'distill.py', 'register.py',
             'protocol.json', 'training-cases.json', 'replay.json', 'build_bundle.py'):
    add(study / name)
for name in ('camera-xy-primitive.npz', 'demonstrations.json', 'fit.json'):
    add(study / 'model' / name)
for directory in ('teacher', 'development'):
    for path in sorted((study / directory).iterdir()):
        if path.suffix in ('.json', '.zlib'):
            add(path)
for name in ('piper_first_attempt_eval.py', 'piper_first_attempt_policy.py',
             'piper_first_attempt_replay.py', 'piper_workspace_calibration.py'):
    add(source / name, f'source-overlay/dvidia_training/{name}')
for name in ('development.json', 'workspace/nominal.json'):
    add(benchmark / name, f'benchmark/{name}')

sample = json.loads(files['development/development-00-g0-learned.json'])
files['example-observation.jsonl'] = (json.dumps(dict(
    t_seconds=0., joint_position_rad=[0., 1.57, -1.3485, 0., 0., 0.],
    initial_object_position_world_m=sample['initial_tracker']['object_position_world_m'],
    goal_position_world_m=sample['case']['goal_position_m'],
), sort_keys=True) + '\n').encode()

manifest = dict(schema='dvidia.piper-corner-distillation-bundle/v1',
                base_training_commit='e13ff91fe2466cf630fe49c0dd0993dfafdd8e0e',
                scope='local_simulation_research',
                members_sha256={name: sha256(data).hexdigest() for name, data in sorted(files.items())})
files['manifest.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()

archive = study / 'piper-camera-xy-distillation-v1.zip'
with ZipFile(archive, 'x', compression=ZIP_DEFLATED, compresslevel=6) as output:
    for name, data in sorted(files.items()):
        entry = ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        entry.compress_type = ZIP_DEFLATED
        entry.external_attr = 0o100644 << 16
        output.writestr(entry, data, compresslevel=6)
print(f'{archive.name} {archive.stat().st_size} bytes {sha256(archive.read_bytes()).hexdigest()}')
