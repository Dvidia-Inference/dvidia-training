# Distilling the camera-initialized PiPER placement

A 195 kB NumPy model fitted to 32 camera-initialized simulator demonstrations placed the block on all 12 development attempts. The nearest-demonstration baseline also placed all 12. The model produced lower peak pad force on every matched attempt, with a median of 0.86 N compared with 6.09 N from retrieval.

The frozen authored controller generated 32 complete, strict demonstrations from 16 positions and two destinations. Each used one surveyed RGB-D observation, 50 Hz encoders and the stock PiPER gripper. Collection took 62.0 seconds of local wall time summed across 32 episodes. The learner consumed only the measured initial camera XY, destination, simulation time and issued targets. It fitted the complete six-joint and one-jaw target sequence, including approach, grasp, lift, carry, release and retreat. At evaluation, the learned commands computed from the camera anchor and the clock ran under the same actuator bounds as retrieval. The measured joints bounded the requested step. The learned policy had no teacher fallback, grasp phase rules, or direct access to physics truth.

| Development metric | Learned | Nearest demonstration |
|---|---:|---:|
| Strict placements | 12/12 | 12/12 |
| Critical-contact episodes | 0/12 | 0/12 |
| Median strict completion, simulated | 14.3665 s | 14.3800 s |
| Median terminal XY error | 4.28 mm | 3.30 mm |
| Median per-episode peak pad force | 0.855 N | 6.094 N |
| Maximum observed pad force | 0.980 N | 9.213 N |
| Median per-episode p95 policy compute | 0.0187 ms | 0.0162 ms |
| Median per-episode max policy compute | 0.4033 ms | 0.2567 ms |

The fit took 8.18 ms on the local Darwin arm64 host with Python 3.12.9, NumPy 2.5.3 and MuJoCo 3.15.0. Fit time covers the solve and in-sample error calculation. Policy timings cover the in-memory prediction and command bounds. Capture, encoding, physics and any hardware I/O have distinct timing scopes.

The 12 scored scenes span six starting positions excluded from model fitting, two destinations and three fixed material strata. The authored teacher had previously been developed against these same scenes. These results establish reproducibility within the development protocol, while the separate project confirmation roster remains untouched by this experiment. The trial covers one upright 40 mm rigid block and two surveyed regions. The learned policy interpolates a preplanned trajectory after seeing the initial frame. Grip feedback, perturbation recovery, ordinary human video, physical robot transfer and unfamiliar object shapes are outside this trial.

## Reproduce

From the worktree, run with the training environment's Python, `PYTHONPATH=src` and the pinned PiPER assets. These commands take fresh output directories. Offscreen rendering needs a local graphics context for collection and live evaluation.

```sh
study=runs/first-attempt/corner-distillation
benchmark=benchmarks/piper-first-attempt-v01

python -m dvidia_training.piper_first_attempt_eval \
  --cases "$study/training-cases.json" --assets "$PIPER_ASSETS" \
  --controller corner-v8 --calibration "$benchmark/workspace/nominal.json" \
  --output "$study/teacher-reproduction"

python "$study/distill.py" train --demonstrations "$study/teacher-reproduction" \
  --output "$study/model-reproduction"

python "$study/distill.py" evaluate --cases "$benchmark/development.json" \
  --assets "$PIPER_ASSETS" --calibration "$benchmark/workspace/nominal.json" \
  --model "$study/model-reproduction" --output "$study/development-reproduction"

python "$study/verify_replay.py" --assets "$PIPER_ASSETS" \
  --receipts "$study/development-reproduction" --output "$study/replay-reproduction.json"
```

The registered protocol and training cases were written before collection. The model artifact is `model/camera-xy-primitive.npz` with SHA-256 `aa0e1cc395954099fae954a479aa703b6cc0062a10d2ac5bed9390b96ab45c00`. The fit receipt binds the protocol, the training index and the model. `development/summary.json` reports the paired outcomes. Per-scene receipts and exact issued command tapes are stored next to the summary.
