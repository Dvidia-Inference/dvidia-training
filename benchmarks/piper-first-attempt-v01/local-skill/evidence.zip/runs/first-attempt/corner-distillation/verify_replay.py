"""Replay the exact evaluation commands headlessly, without the model or camera."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from dvidia_training.piper_first_attempt_replay import replay


def main():
    parser = ArgumentParser(description=__doc__)
    for argument in ('assets', 'receipts', 'output'):
        parser.add_argument('--' + argument, type=Path, required=True)
    args = parser.parse_args()
    results = []
    with TemporaryDirectory(dir=args.output.parent) as directory:
        staging = Path(directory)
        for receipt in sorted(args.receipts.glob('development-*-g*-*.json')):
            evidence = json.loads(receipt.read_text())
            binding = evidence['action_log']
            recorded = args.receipts / binding['path']
            # The replay verifier expects the CLI's dash-delimited tape suffix.
            # Normalize only this local copy's filename, without changing bytes.
            standardized = staging / (receipt.stem + '-actions.f64.zlib')
            standardized.symlink_to(recorded.resolve())
            binding['path'] = standardized.name
            renamed = staging / receipt.name
            renamed.write_text(json.dumps(evidence))
            result = replay(args.assets, renamed)
            results.append(dict(
                controller=evidence['controller'],
                case=result['case_id'],
                reproduced=result['reproduced'],
                mismatches=result['mismatches'],
                native_ticks=result['observed']['native_ticks'],
                strict_success=result['observed']['success'],
                source_receipt_sha256=sha256(receipt.read_bytes()).hexdigest(),
                executed_commands_sha256=result['observed']['executed_commands_sha256'],
            ))
    if len(results) != 24:
        raise ValueError(f'Expected 24 evaluation receipts, found {len(results)}.')
    with args.output.open('x') as stream:
        json.dump(results, stream, sort_keys=True, indent=2)
        stream.write('\n')
    matched = sum(result['reproduced'] for result in results)
    print(f'Reproduced {matched}/{len(results)} exact action streams and strict outcomes.')
    return int(matched != len(results))


if __name__ == '__main__':
    raise SystemExit(main())
