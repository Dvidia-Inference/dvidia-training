"""Write the fixed development-only distillation protocol before collection."""
from datetime import datetime, timezone
from hashlib import sha256
from itertools import product
import json
from pathlib import Path

root = Path(__file__).resolve().parents[3]
directory = Path(__file__).resolve().parent
benchmark = root / 'benchmarks/piper-first-attempt-v01'
development = benchmark / 'development.json'
calibration = benchmark / 'workspace/nominal.json'
source = root / 'src/dvidia_training/piper_first_attempt_policy.py'
mass_friction = ((.04, .8), (.06, .55), (.03, .7))
destinations = ((.35, .08, .08), (.40, -.08, .08))


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


cases = []
for group, (x, y) in enumerate(product((.286, .295, .304, .313), (-.044, -.035, -.026, -.017))):
    mass, friction = mass_friction[group % 3]
    for goal, destination in enumerate(destinations):
        cases.append(dict(
            id=f'corner-train-{group:02}-g{goal}', group_id=f'corner-train-{group:02}',
            goal_id=goal, seed=180400 + group, object_position_m=[x, y, .082],
            goal_position_m=destination, mass_kg=mass, friction=friction,
        ))
development_cases = json.loads(development.read_text())
assert not {tuple(c['object_position_m'][:2]) for c in cases} & {
    tuple(c['object_position_m'][:2]) for c in development_cases
}
protocol = dict(
    schema='dvidia.piper-corner-distillation-protocol/v1',
    registered_utc=datetime.now(timezone.utc).isoformat(),
    scope='Supplemental simulation development study. Twelve prior development trials are held out from model fit. One attempt per case and policy. Retain all outcomes.',
    training_cases=cases,
    development_case_ids=[c['id'] for c in development_cases],
    development_roster_sha256=digest(development),
    workspace_calibration_sha256=digest(calibration),
    teacher_sha256=digest(source),
    teacher='Frozen authored corner-v8, one surveyed RGB-D anchor, 50 Hz encoders, no native state or teacher fallback.',
    data_quality_gate='A complete strict successful demonstration for each of the 16 starts and at least 14 successful demonstrations per goal. Successful-only fitting, with refusals/errors retained. Rank-deficient spatial fits block training.',
    regression=dict(
        algorithm='separable ridge fit using normalized Gaussian time basis and polynomial XY basis',
        centers=201, center_spacing_s=.1, gaussian_width_s=.075, spatial_ridge=1e-5,
        temporal_ridge=1e-5, spatial_terms=['1', 'y', 'y^2', 'x', 'x*y', 'x*y^2', 'x^2', 'x^2*y', 'x^2*y^2'],
        normalized_targets='six absolute joint targets divided by three and one jaw target divided by 0.035',
        features='one historical camera XY, one of two task destinations, elapsed seconds',
        runtime_constraints='50 Hz. Measured joint encoders only for ±0.06 rad step clipping. Original 0.02 rad joint margins and 0.035 m jaw bound. Original native slew limits.',
    ),
    comparison=[
        'Frozen compact learned primitive',
        'Nearest successful demonstration for same goal by Euclidean distance between historical RGB-D XY estimates, with identical action bounds.',
    ],
    metrics='Strict native outcome then contacts, force, completion time, terminal XY error and local timing. Cases grouped by starting position. Report fit latency and package bytes.',
)
with (directory / 'protocol.json').open('x') as stream:
    json.dump(protocol, stream, sort_keys=True, indent=2)
    stream.write('\n')
with (directory / 'training-cases.json').open('x') as stream:
    json.dump(cases, stream, indent=2)
    stream.write('\n')
print(digest(directory / 'protocol.json'))
