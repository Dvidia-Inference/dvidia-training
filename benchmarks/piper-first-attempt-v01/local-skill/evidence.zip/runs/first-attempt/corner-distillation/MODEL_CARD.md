# Model card

**Artifact.** `model/camera-xy-primitive.npz` is a 194,832-byte NumPy archive with one float64 weight array of shape `(2, 9, 201, 7)`. Its SHA-256 is `aa0e1cc395954099fae954a479aa703b6cc0062a10d2ac5bed9390b96ab45c00`.

**Purpose.** This simulated PiPER research model reproduces a taught rigid-block placement using one historical camera position and two fixed destinations. The bundle supplies NumPy inference and the experiment recipe. The runner emits simulated setpoints over stdout and has no physical actuator connection.

**Method.** CPU polynomial spatial regression and a Gaussian time basis fit six absolute joint targets and one gripper target across 32 successful authored simulator demonstrations. The model computes a trajectory when it first sees a valid historical RGB-D position. Thereafter the measured arm joints constrain the requested step, while elapsed time selects the trajectory reference. Native actuator limits and slew rates apply in the simulator.

**Evaluation.** An independent 1 ms MuJoCo scorer verified 12/12 development placements, including both destinations, all three fixed material conditions and six starting positions excluded from model fit. Nearest demonstration retrieval matched all 12 placements. The learned model had lower per-episode peak pad force on 12/12 matched trials. The held-out development positions were previously used to develop the authored teacher. The separate confirmation cohort is outside this study.

**Limits.** One predetermined 40 mm cube is upright on a surveyed level work surface. The model interpolates pose-conditioned commands and cannot verify the block's retention, replan around obstacles, recover from a dropped block or infer actions from ordinary human video. Physical robot readiness is unverified. This model should be evaluated with the provided simulator contract.

**Timing.** The ridge solve and in-sample error calculation took 8.18 ms. Median per-episode p95 policy compute was 0.0187 ms on one Darwin arm64 host. This excludes camera capture, physics and hardware actuation.

See [the report](REPORT.md), [fit receipt](model/fit.json) and [benchmark summaries](development/summary.json).
