# PiPER camera-to-action research bundle

The model consumes one historical simulated camera position and generates the entire placement sequence at a 50 Hz control clock. Local inference needs Python 3.12 and NumPy 2.5.3. The packaged command interface has no network or physical arm dependency.

From the extracted bundle, run the included first simulated observation:

```sh
python -I policy.py --model model/camera-xy-primitive.npz < example-observation.jsonl
```

For another episode, supply newline-delimited objects conforming to the example. Use metres for camera and destination, radians for measured arm positions and seconds for the simulation clock. Begin with a fresh process or a fresh `Policy` object for each episode. The destination is one of `[0.35, 0.08, 0.08]` and `[0.40, -0.08, 0.08]` in the fixed survey frame. The first line supplies the historical camera position. Subsequent lines may omit it. Provide actual measured simulated joints at each step. The output contains six requested joint targets and one requested gripper target for each input line.

The experiment recipe uses the DVIDIA Training PiPER simulator, MuJoCo 3.15.0 and pinned assets. The development experiment used base commit `e13ff91fe2466cf630fe49c0dd0993dfafdd8e0e` with the four versioned source files in `source-overlay/`. Overlay those files on the matching local package before reproducing the experiment. Existing official entry points remain part of that repository. The included archives and local metrics can be read without installing a robot driver.

`teacher/` contains exact recorded demonstration targets and paired camera/scoring receipts. `development/` includes exact learned and nearest-demonstration tapes. `replay.json` records a renderer-free replay of all 24 evaluation tapes. `manifest.json` binds the bundle contents. [Model card](MODEL_CARD.md) · [Data card](DATA_CARD.md) · [Experiment report](REPORT.md)
