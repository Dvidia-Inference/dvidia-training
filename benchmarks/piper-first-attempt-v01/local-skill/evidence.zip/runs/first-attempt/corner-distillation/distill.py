"""Fit and evaluate the preregistered supplemental PiPER experiment."""
from argparse import ArgumentParser
from collections import Counter
from hashlib import sha256
import json
import math
from pathlib import Path
from statistics import median
from time import perf_counter
from unittest.mock import patch
import zlib

import numpy as np

from dvidia_training import piper_first_attempt_eval as study
from dvidia_training import piper_first_attempt_policy as reference
from dvidia_training.piper_imitation import JAW_MAX_M, JOINT_DELTA_RAD, JOINT_LIMITS
from dvidia_training.piper_motor_primitive import GOALS, _goal, _spatial, _time_basis


DIRECTORY = Path(__file__).resolve().parent
STEPS = 1000
DT = .02
RIDGE = 1e-5
TIME_DESIGN = _time_basis(np.arange(STEPS) * DT)
ACTION_SCALE = np.array([3.] * 6 + [JAW_MAX_M])
LOWER, UPPER = np.asarray(JOINT_LIMITS).T
POLICIES = ('learned', 'nearest')


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def xy(values):
    point = np.asarray(values, dtype=float)
    if point.shape != (3,) or not np.isfinite(point).all():
        raise ValueError('Expected a valid historical camera position.')
    return point[:2]


def read_demonstrations(directory, planned, protocol):
    successful = []
    index = []
    for number, case in enumerate(planned):
        path = directory / f'attempt-{number:04}.json'
        receipt = json.loads(path.read_text())
        if receipt['case']['id'] != case['id'] or receipt['controller'] != 'corner-v8':
            raise ValueError(f'Receipt mismatches registered teacher case {case["id"]}.')
        if (receipt['source_sha256']['piper_first_attempt_policy.py'] != protocol['teacher_sha256']
                or receipt['calibration_file_sha256'] != protocol['workspace_calibration_sha256']):
            raise ValueError(f'Receipt source/calibration mismatch for {case["id"]}.')
        summary = dict(case_id=case['id'], group_id=case['group_id'], goal_id=case['goal_id'],
                       receipt_sha256=digest(path), status=receipt['status'],
                       strict_success=receipt['success'], failure_stage=receipt.get('failure_stage'))
        index.append(summary)
        if not receipt['valid'] or not receipt['success']:
            continue
        if receipt['control_steps'] != STEPS or receipt['initial_camera_pairs_delivered'] != 1:
            raise ValueError(f'Incomplete successful teacher receipt for {case["id"]}.')
        action_log = receipt['action_log']
        tape_path = directory / f'attempt-{number:04}-actions.f64.zlib'
        if action_log['path'] != tape_path.name or action_log['sha256'] != digest(tape_path):
            raise ValueError(f'Action archive mismatch for {case["id"]}.')
        actions = np.frombuffer(zlib.decompress(tape_path.read_bytes()), dtype='<f8').reshape(STEPS, 7)
        if (not np.isfinite(actions).all() or np.any(actions[:, :6] < LOWER)
                or np.any(actions[:, :6] > UPPER) or np.any(actions[:, 6] < 0)
                or np.any(actions[:, 6] > JAW_MAX_M)):
            raise ValueError(f'Invalid demonstrated targets for {case["id"]}.')
        anchor = xy(receipt['initial_tracker']['object_position_world_m'])
        summary.update(action_log_sha256=action_log['sha256'], initial_camera_xy_m=anchor.tolist())
        successful.append((case['goal_id'], anchor, actions))
    return index, successful


def ridge_projection(design):
    normal = design.T @ design + RIDGE * np.eye(design.shape[1])
    return np.linalg.solve(normal, design.T)


def fit_model(goals, anchors, actions):
    time_projection = ridge_projection(TIME_DESIGN)
    weights, errors = [], []
    for goal in range(len(GOALS)):
        select = goals == goal
        space = _spatial(anchors[select])
        if np.linalg.matrix_rank(space) != space.shape[1]:
            raise ValueError('The registered successful demonstrations leave the fit rank deficient.')
        intended = actions[select] / ACTION_SCALE
        mixed = np.tensordot(ridge_projection(space), intended, axes=(1, 0))
        parameters = np.einsum('stj,kt->skj', mixed, time_projection, optimize=True)
        predict = np.einsum('ns,skj,tk->ntj', space, parameters, TIME_DESIGN, optimize=True)
        weights.append(parameters)
        errors.append((predict - intended) * ACTION_SCALE)
    rmse = np.sqrt(np.mean(np.concatenate(errors) ** 2, axis=(0, 1)))
    return np.stack(weights), rmse


def train(protocol, source, output):
    output.mkdir(exist_ok=False)
    records, demos = read_demonstrations(source, protocol['training_cases'], protocol)
    successful = [row for row in records if row['strict_success']]
    groups = {case['group_id'] for case in protocol['training_cases']}
    count_by_goal = Counter(row['goal_id'] for row in successful)
    receipt = dict(
        scope='development_only_simulation', teacher=protocol['teacher'],
        protocol_sha256=digest(DIRECTORY / 'protocol.json'), fit_source_sha256=digest(__file__),
        training_attempts=len(records), successful_demonstrations=len(successful),
        successful_by_goal=dict(count_by_goal), unique_successful_groups=len({r['group_id'] for r in successful}),
        training_dataset_index_sha256=sha256(json.dumps(records, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
    )
    write_json(output / 'demonstrations.json', records)
    if {r['group_id'] for r in successful} != groups or min(count_by_goal[g] for g in range(len(GOALS))) < 14:
        receipt.update(status='blocked', reason='registered_demonstration_quality_gate_failed')
        write_json(output / 'fit.json', receipt)
        return 1
    goals, anchors, actions = (np.asarray(batch) for batch in zip(*demos))
    began = perf_counter()
    weights, rmse = fit_model(goals, anchors, actions)
    fit_seconds = perf_counter() - began
    model = output / 'camera-xy-primitive.npz'
    np.savez_compressed(model, weights=weights)
    np.savez_compressed(output / 'retrieval.npz', goals=goals, anchors=anchors, actions=actions)
    receipt.update(status='trained', fit_seconds=fit_seconds, fit_native_rmse=rmse.tolist(),
                   model_file=model.name, model_sha256=digest(model), model_bytes=model.stat().st_size)
    write_json(output / 'fit.json', receipt)
    print(json.dumps(receipt, sort_keys=True), flush=True)
    return 0


class Controller:
    def __init__(self, policy, parameters):
        self.phase = policy
        self.parameters = parameters
        self.index = 0
        self.reference = None
        self.goal = None

    def __call__(self, observation):
        if not math.isclose(observation['t_seconds'], self.index * DT, rel_tol=0., abs_tol=1e-8):
            raise ValueError('The learned primitive requires a stable 50 Hz decision clock.')
        goal = _goal(observation['goal_position_world_m'])
        if self.reference is None:
            anchor = xy(observation['initial_object_position_world_m'])
            if self.phase == 'learned':
                # Precompute this episode's reference from the camera estimate
                # and destination. All coefficients were fitted before evaluation.
                coefficients = np.einsum('s,stj->tj', _spatial(anchor), self.parameters['weights'][goal])
                self.reference = (TIME_DESIGN @ coefficients) * ACTION_SCALE
            else:
                candidates = np.flatnonzero(self.parameters['goals'] == goal)
                differences = self.parameters['anchors'][candidates] - anchor
                nearest = candidates[np.argmin(np.sum(differences ** 2, axis=1))]
                self.reference = self.parameters['actions'][nearest]
            self.goal = goal
        if goal != self.goal:
            raise ValueError('Destination changed within the rollout.')
        row = self.reference[self.index]
        q = np.asarray(observation['joint_position_rad'])
        targets = np.clip(q + np.clip(row[:6] - q, -JOINT_DELTA_RAD, JOINT_DELTA_RAD), LOWER + .02, UPPER - .02)
        self.index += 1
        return dict(joint_targets_rad=targets.tolist(), gripper_position_m=float(np.clip(row[6], 0., JAW_MAX_M)))


def report(rows):
    completed = [r for r in rows if r['valid'] and r['status'] == 'completed']
    placed = [r for r in completed if r['success']]

    def middle(values):
        return median(values) if values else None

    return dict(
        attempts=len(rows), completed=len(completed), strict_successes=len(placed),
        statuses=dict(Counter(row['status'] for row in rows)),
        failure_stages=dict(Counter(row.get('failure_stage', 'unrecorded') for row in rows if not row['success'])),
        critical_contact_episodes=sum(row['critical_contact_native_ticks'] > 0 for row in completed),
        peak_pad_force_n=max((max(row['peak_pad_force_n'].values()) for row in completed), default=None),
        median_success_sim_s=middle([row['first_success_time_s'] for row in placed]),
        median_success_xy_error_mm=middle([1000 * row['final_xy_error_m'] for row in placed]),
        median_inference_p95_ms=middle([row['inference_wall']['p95_ms'] for row in completed]),
        median_inference_max_ms=middle([row['inference_wall']['max_ms'] for row in completed]),
        median_attempt_wall_s=middle([row['attempt_wall_s'] for row in completed]),
    )


def evaluate(args, protocol):
    if digest(args.cases) != protocol['development_roster_sha256']:
        raise ValueError('Only the preregistered twelve development cases are admissible.')
    if digest(args.calibration) != protocol['workspace_calibration_sha256']:
        raise ValueError('Calibration differs from the registered teacher setup.')
    cases = json.loads(args.cases.read_text())
    fit = json.loads((args.model / 'fit.json').read_text())
    if fit['status'] != 'trained':
        raise ValueError('No fitted candidate passed the data-quality gate.')
    if digest(args.model / fit['model_file']) != fit['model_sha256']:
        raise ValueError('The fitted model has changed.')
    args.output.mkdir(exist_ok=False)
    results = {name: [] for name in POLICIES}
    for label in POLICIES:
        model_path = args.model / (fit['model_file'] if label == 'learned' else 'retrieval.npz')
        with np.load(model_path, allow_pickle=False) as archive:
            parameters = {name: archive[name] for name in archive.files}

        def make_policy(name, kinematics):
            if name != label:
                raise ValueError('Unexpected controller.')
            return Controller(name, parameters)

        with patch.object(reference, 'make_policy', make_policy):
            for case in cases:
                attempt = args.output / f'{case["id"]}-{label}'
                write_json(attempt.with_suffix('.started'), dict(case=case['id'], controller=label))
                receipt = study.run_attempt(args.assets, case, label, calibration=args.calibration,
                                            action_log=attempt.with_suffix('.actions.f64.zlib'))
                receipt.update(installed_artifact_sha256=digest(model_path),
                               policy_implementation_sha256=digest(__file__),
                               training_dataset_index_sha256=fit['training_dataset_index_sha256'])
                write_json(attempt.with_suffix('.json'), receipt)
                results[label].append(receipt)
                print(case['id'], label, receipt['status'], receipt['success'], receipt['reason'], flush=True)
    totals = {label: report(rows) for label, rows in results.items()}
    paired = [[a['success'], b['success']] for a, b in zip(results['learned'], results['nearest'])]
    totals['paired_strict_success'] = dict(
        learned_only=sum(a and not b for a, b in paired),
        nearest_only=sum(b and not a for a, b in paired),
        both=sum(a and b for a, b in paired),
        neither=sum(not a and not b for a, b in paired))
    write_json(args.output / 'summary.json', totals)
    print(json.dumps(totals, sort_keys=True))
    return 0


def main():
    cli = ArgumentParser(description=__doc__)
    subs = cli.add_subparsers(dest='stage', required=True)
    trainer = subs.add_parser('train')
    trainer.add_argument('--demonstrations', required=True, type=Path)
    trainer.add_argument('--output', required=True, type=Path)
    evaluator = subs.add_parser('evaluate')
    for key in ('cases', 'assets', 'calibration', 'model', 'output'):
        evaluator.add_argument('--' + key, required=True, type=Path)
    args = cli.parse_args()
    protocol = json.loads((DIRECTORY / 'protocol.json').read_text())
    if args.stage == 'train':
        return train(protocol, args.demonstrations, args.output)
    return evaluate(args, protocol)


if __name__ == '__main__':
    raise SystemExit(main())
