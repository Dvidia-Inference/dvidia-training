"""Development-only native cube-yaw experiment; changes no frozen source."""
import argparse
from hashlib import sha256
import json
import math
from pathlib import Path
from unittest.mock import patch

from dvidia_training import piper_first_attempt_eval as study
from dvidia_training import piper_first_attempt_policy as frozen
from dvidia_training import piper_rgbd_tracker as tracker
from dvidia_training import piper_task
from piper_yaw_adapter import make_policy as reachable_policy

frozen_factory = frozen.make_policy


def make_policy(name, kinematics):
    if name == 'fixed-corner':
        return frozen_factory('corner-v8', kinematics)
    return reachable_policy(name, kinematics)


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def yaw_degrees(q):
    return math.degrees(2 * math.atan2(q[3], q[0]))


def run(args, case, controller):
    scene_yaw = case['yaw_degrees']
    physics_case = {k: v for k, v in case.items() if k != 'yaw_degrees'}
    recorded = {}
    original_build = piper_task.build_task_model
    original_estimate = tracker.estimate_pose
    original_observe = study._observe

    def build_rotated_model(*params, **kwargs):
        model = original_build(*params, **kwargs)
        mj, _ = piper_task.sim._native_imports()
        joint = mj.mj_name2id(model, mj.mjtObj.mjOBJ_JOINT, 'task_block_free')
        if joint < 0 or model.jnt_type[joint] != mj.mjtJoint.mjJNT_FREE:
            raise ValueError('Expected the unmodified cube free joint.')
        first = int(model.jnt_qposadr[joint]) + 3
        a = math.radians(scene_yaw) / 2.
        # The standard reset creates MjData from qpos0 next, then settles the
        # supported object for the original interval and validates the reset.
        model.qpos0[first:first+4] = [math.cos(a), 0., 0., math.sin(a)]
        return model

    def capture_estimate(*params, **kwargs):
        value = original_estimate(*params, **kwargs)
        if value['status'] == 'available':
            recorded['camera_quaternion'] = list(value['object_quaternion_estimate_wxyz'])
        return value

    def observe(*params, **kwargs):
        values = original_observe(*params, **kwargs)
        if controller == 'image-yaw-reachable':
            values['initial_object_quaternion_world_wxyz'] = recorded['camera_quaternion'].copy()
        return values

    class CaptureSettledYaw(study._MaterialSession):
        def native_evidence(self):
            arrays, meta = super().native_evidence()
            # This callback first executes after all 1,000 decisions.
            recorded['initial_native_quaternion'] = arrays['object_quaternion_wxyz'][0].tolist()
            return arrays, meta

    with patch.object(piper_task, 'build_task_model', build_rotated_model), \
            patch.object(study, '_MaterialSession', CaptureSettledYaw), \
            patch.object(study, '_observe', observe), \
            patch.object(tracker, 'estimate_pose', capture_estimate), \
            patch.object(frozen, 'make_policy', make_policy):
        result = study.run_attempt(args.assets, physics_case, controller,
                                    calibration=args.calibration, trace=False)
    camera = recorded.get('camera_quaternion')
    native = recorded.get('initial_native_quaternion')
    if native is not None:
        recorded['settled_native_yaw_deg'] = yaw_degrees(native)
    if camera is not None:
        recorded['camera_yaw_deg'] = yaw_degrees(camera)
    if native is not None and camera is not None:
        recorded['camera_yaw_error_mod90_deg'] = abs((yaw_degrees(camera)-yaw_degrees(native)+45.) % 90. - 45.)
    recorded['registered_initial_yaw_deg'] = scene_yaw
    result['yaw_diagnostic'] = recorded
    result['yaw_plan_sha256'] = digest(args.plan)
    result['yaw_driver_sha256'] = digest(__file__)
    result['yaw_adapter_sha256'] = digest(Path(__file__).with_name('piper_yaw_adapter.py'))
    return result


def main():
    cli = argparse.ArgumentParser()
    for key in ('plan', 'assets', 'calibration', 'output'):
        cli.add_argument('--'+key, type=Path, required=True)
    args = cli.parse_args()
    plan = json.loads(args.plan.read_text())
    expected = {
        'workspace_calibration_sha256': args.calibration,
        'reference_policy_sha256': frozen.__file__,
        'yaw_adapter_sha256': Path(__file__).with_name('piper_yaw_adapter.py'),
    }
    for key, path in expected.items():
        if digest(path) != plan[key]:
            raise ValueError(f'Source changed since registration: {key}')
    if len(set(c['id'] for c in plan['cases'])) != len(plan['cases']):
        raise ValueError('Case IDs must be unique')
    args.output.mkdir(exist_ok=False)
    receipt_index = []
    for case in plan['cases']:
        for controller in plan['controllers']:
            result = run(args,case,controller)
            path = args.output/(case['id']+'-'+controller+'.json')
            with path.open('x') as f:
                json.dump(result,f,indent=2,sort_keys=True,allow_nan=False)
                f.write('\n')
            receipt_index.append({'file':path.name, 'sha256':digest(path),
                                  'success':result['success'], 'status':result['status']})
            print(path.name,result['status'],result['success'],result['reason'],flush=True)
    (args.output/'index.json').write_text(json.dumps(receipt_index,indent=2)+'\n')


if __name__ == '__main__':
    main()
