"""Write the rotated-block paired development study registration."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path

out = Path(__file__).resolve().parent
bench = out.parents[2] / 'benchmarks/piper-first-attempt-v01'
learner = out.parent / 'corner-distillation'
base_roster = bench / 'development.json'


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


cases = []
development = json.loads(base_roster.read_text())
for case in development:
    for yaw in (-32, 24):
        cases.append(dict(case, id=f"{case['id']}-yaw{yaw:+d}", yaw_degrees=yaw))
assert len(cases) == 24 and len({c['group_id'] for c in cases}) == 6
protocol = dict(
    schema='dvidia.piper-distilled-yaw-development/v1',
    registered_utc=datetime.now(timezone.utc).isoformat(),
    scope='Simulation development only. Keep one attempt per case and controller. No parameter tuning, replacement trials, teacher fallback or confirmation access.',
    cases=cases,
    controllers=['learned_fixed_yaw', 'learned_camera_yaw'],
    model_sha256=digest(learner/'model/camera-xy-primitive.npz'),
    learned_policy_source_sha256=digest(learner/'policy.py'),
    workspace_calibration_sha256=digest(bench/'workspace/nominal.json'),
    development_roster_sha256=digest(base_roster),
    driver_sha256=digest(out/'driver.py'),
    yaw_adapter_sha256=digest(out/'adapter.py'),
    initial_geometry_check_sha256=digest(out/'geometry.json'),
    candidate='Both arms run the same frozen NumPy model. The variant adds local wrist twist -phi+k*pi/2, k=-2..2, using phi modulo 90 degrees from the single initial RGB-D estimate. Retain candidates keeping the complete adjusted reference inside native joint6 margins. Among those choose minimum difference from initial measured joint6 to predicted adjusted joint6 at first learned jaw target <.0175 m. Break ties by smallest absolute twist then k. Ramp twist quintically from zero to full 0.30 s before first predicted closure. Retain the offset throughout. All output slew and encoder delta limits apply. Preserve the unchanged first action.',
    sensory_contract='One initial RGB-D position for both, with initial observed quaternion added only to the variant. Known destination and 50 Hz clock. All subsequent measured arm positions enter the stock joint step limiter. No truth yaw, native contacts, material labels or task phase signals reach either policy.',
    metrics='Independently scored strict native placement, critical contacts, peak pad force, completion time, and final XY error. Track settled native cube yaw and tracker error modulo 90 degrees for post-hoc diagnostics only. Track chosen twist and predicted timing. Compare paired success discordances and all fixed cases.',
)
with (out/'protocol.json').open('x') as stream:
    json.dump(protocol,stream,sort_keys=True,indent=2)
    stream.write('\n')
print(digest(out/'protocol.json'))
