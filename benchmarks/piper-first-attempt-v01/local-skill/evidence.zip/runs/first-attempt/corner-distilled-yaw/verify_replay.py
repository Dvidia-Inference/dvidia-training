"""Rebuild each rotated scene and replay the exact commands without a renderer."""
from argparse import ArgumentParser
from hashlib import sha256
import json
import math
from pathlib import Path
from unittest.mock import patch

import numpy as np

from dvidia_training import piper_task
from dvidia_training.piper_first_attempt_replay import read_actions, replay


def scene_builder(yaw_degrees, original):
    radians = math.radians(yaw_degrees)

    def build(*args, **kwargs):
        model = original(*args, **kwargs)
        mj, _ = piper_task.sim._native_imports()
        joint = mj.mj_name2id(model, mj.mjtObj.mjOBJ_JOINT, 'task_block_free')
        if joint < 0 or model.jnt_type[joint] != mj.mjtJoint.mjJNT_FREE:
            raise ValueError('The expected free cube joint is missing.')
        address = int(model.jnt_qposadr[joint])
        model.qpos0[address+3:address+7] = [math.cos(radians/2.), 0., 0., math.sin(radians/2.)]
        return model

    return build


def main():
    cli = ArgumentParser(description=__doc__)
    for name in ('assets', 'plan', 'receipts', 'output'):
        cli.add_argument('--' + name, required=True, type=Path)
    args = cli.parse_args()
    protocol = json.loads(args.plan.read_text())
    original = piper_task.build_task_model
    results = []
    for case in protocol['cases']:
        first_action = None
        for controller in protocol['controllers']:
            path = args.receipts / (case['id'] + '-' + controller + '.json')
            document = json.loads(path.read_text())
            if document['case']['id'] != case['id'] or document['controller'] != controller:
                raise ValueError('Receipt mismatches preregistered case or policy.')
            if document['yaw_plan_sha256'] != sha256(args.plan.read_bytes()).hexdigest():
                raise ValueError('Receipt mismatches preregistration hash.')
            if document['status'] != 'completed':
                results.append(dict(case=case['id'], controller=controller, reproduced=False,
                                    reason=document['reason']))
                continue
            actions = read_actions(args.receipts, document['action_log'])
            if first_action is None:
                first_action = actions[0].copy()
            elif not np.array_equal(first_action, actions[0]):
                raise ValueError('Yaw adaptation changed the initial action.')
            with patch.object(piper_task, 'build_task_model', scene_builder(case['yaw_degrees'], original)):
                observed = replay(args.assets, path)
            results.append(dict(case=case['id'], controller=controller, reproduced=observed['reproduced'],
                                mismatches=observed['mismatches'], strict_success=observed['observed']['success'],
                                source_receipt_sha256=observed['receipt_sha256'],
                                command_stream_sha256=observed['observed']['executed_commands_sha256']))
    count = sum(result['reproduced'] for result in results)
    with args.output.open('x') as stream:
        json.dump(dict(reproduced=count, scheduled=len(results), trials=results), stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(f'Headless replay reproduced {count}/{len(results)} exact target streams and outcomes.')
    return int(count != len(results))


if __name__ == '__main__':
    raise SystemExit(main())
