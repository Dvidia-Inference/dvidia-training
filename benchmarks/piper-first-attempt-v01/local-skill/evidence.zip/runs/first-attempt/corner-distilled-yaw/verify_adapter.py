"""Check the foreknown-reference adaptation boundaries without simulation."""
from copy import deepcopy
import math
from pathlib import Path
import unittest

import numpy as np

from adapter import InitialYawPolicy, WRIST_HIGH, WRIST_LOW
from driver import load_policy


ROOT = Path(__file__).resolve().parent.parent / 'corner-distillation'


class AdapterTests(unittest.TestCase):
    def test_learned_first_command_and_all_non_wrist_reference_columns_are_preserved(self):
        policy_class = load_policy(ROOT / 'policy.py')
        model = ROOT / 'model/camera-xy-primitive.npz'
        original = InitialYawPolicy(policy_class(model), adaptive=False)
        adapted = InitialYawPolicy(policy_class(model), adaptive=True)
        theta = math.radians(-32)
        observation = dict(t_seconds=0., initial_object_position_world_m=[.3, -.03, .08],
                           joint_position_rad=[0., 1.57, -1.3485, 0., 0., 0.],
                           goal_position_world_m=[.35, .08, .08],
                           initial_object_quaternion_world_wxyz=[math.cos(theta / 2.), 0., 0., math.sin(theta / 2.)])
        self.assertEqual(original(observation), adapted(observation))
        before, after = original.base.reference, adapted.base.reference
        np.testing.assert_array_equal(before[:, [0, 1, 2, 3, 4, 6]], after[:, [0, 1, 2, 3, 4, 6]])
        record = adapted.yaw_diagnostics
        delta = after[:, 5] - before[:, 5]
        self.assertEqual(delta[0], 0.)
        self.assertTrue(np.all(after[:, 5] >= WRIST_LOW) and np.all(after[:, 5] <= WRIST_HIGH))
        self.assertAlmostEqual((record['wrist_twist_deg'] - 32. + 45.) % 90. - 45., 0., places=10)
        self.assertAlmostEqual(record['predicted_close_s'] - record['predicted_full_twist_at_s'], .30, places=12)
        unchanged = after.copy()
        next_observation = deepcopy(observation)
        next_observation.update(t_seconds=.02, initial_object_quaternion_world_wxyz=None)
        adapted(next_observation)
        np.testing.assert_array_equal(after, unchanged)


if __name__ == '__main__':
    unittest.main()
