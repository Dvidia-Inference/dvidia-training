"""Verify the frozen robot's local joint6 rotation kinematics."""
from argparse import ArgumentParser
import json
import math

import numpy as np

from dvidia_training.piper_encoder_kinematics import PiperEncoderKinematics
from dvidia_training.piper_first_attempt_policy import _rotation


def geometry(assets):
    kinematics = PiperEncoderKinematics(assets)
    configurations = ([0., 1.57, -1.3485, 0., 0., 0.],
                      [-.1, 1.69, -1.18, .01, 1.06, .67],
                      [.25, 1.53, -1.19, -.24, .94, 1.1],
                      [-.24, 2., -1.62, .23, 1.07, -.3])
    rows = []
    for configuration in configurations:
        fixed = kinematics.fk(configuration)
        for angle in (-1.2, -.37, .42, 1.58):
            updated = list(configuration)
            updated[5] += angle
            moved = kinematics.fk(updated)
            position = np.asarray(fixed['tcp_position_world_m'])
            after = np.asarray(moved['tcp_position_world_m'])
            first = _rotation(np.asarray(fixed['tcp_quaternion_world_wxyz']))
            second = _rotation(np.asarray(moved['tcp_quaternion_world_wxyz']))
            c, s = math.cos(angle), math.sin(angle)
            expected_local_rotation = np.array([[c, -s, 0.], [s, c, 0.], [0., 0., 1.]])
            rows.append(dict(initial_q=configuration, joint6_delta_rad=angle,
                tcp_position_error_m=float(np.linalg.norm(after - position)),
                local_z_rotation_max_element_error=float(np.max(np.abs(first.T @ second - expected_local_rotation)))))
    xyz = max(r['tcp_position_error_m'] for r in rows)
    rotation = max(r['local_z_rotation_max_element_error'] for r in rows)
    if xyz > 1e-10 or rotation > 1e-10:
        raise ValueError(f'Joint6 invariance check failed: {xyz} m, local rotation error {rotation}.')
    return dict(scope='Pinned PiPER encoder FK, no dynamics or cube state.',
                max_tcp_position_error_m=xyz, max_local_rotation_error=rotation, trials=rows)


if __name__ == '__main__':
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('--assets', required=True)
    print(json.dumps(geometry(cli.parse_args().assets), sort_keys=True, indent=2))
