"""Paired development-only evaluation of a yaw adapter for the frozen learned PiPER policy."""
import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from statistics import median
import json
import math
from pathlib import Path
from unittest.mock import patch

from dvidia_training import piper_first_attempt_eval as study
from dvidia_training import piper_first_attempt_policy as frozen
from dvidia_training import piper_rgbd_tracker as tracker
from dvidia_training import piper_task
from adapter import InitialYawPolicy


def load_policy(path):
    spec = spec_from_file_location('frozen_local_policy', path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.Policy


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def yaw_degrees(q):
    return math.degrees(2 * math.atan2(q[3], q[0]))


def run(args, case, controller, output):
    scene_yaw = case['yaw_degrees']
    physics_case = {k: v for k, v in case.items() if k != 'yaw_degrees'}
    recorded = {}
    policy = InitialYawPolicy(args.policy_class(args.model), adaptive=controller == 'learned_camera_yaw')
    original_build = piper_task.build_task_model
    original_estimate = tracker.estimate_pose
    original_observe = study._observe

    def build_rotated_model(*params, **kwargs):
        model = original_build(*params, **kwargs)
        mj, _ = piper_task.sim._native_imports()
        joint = mj.mj_name2id(model, mj.mjtObj.mjOBJ_JOINT, 'task_block_free')
        if joint < 0 or model.jnt_type[joint] != mj.mjtJoint.mjJNT_FREE:
            raise ValueError('Expected the unmodified cube free joint.')
        first = int(model.jnt_qposadr[joint]) + 3
        a = math.radians(scene_yaw) / 2.
        # The standard reset creates MjData from qpos0 next, then settles the
        # supported object for the original interval and validates the reset.
        model.qpos0[first:first+4] = [math.cos(a), 0., 0., math.sin(a)]
        return model

    def capture_estimate(*params, **kwargs):
        value = original_estimate(*params, **kwargs)
        if value['status'] == 'available':
            recorded['camera_quaternion'] = list(value['object_quaternion_estimate_wxyz'])
        return value

    def observe(*params, **kwargs):
        values = original_observe(*params, **kwargs)
        if controller == 'learned_camera_yaw':
            values['initial_object_quaternion_world_wxyz'] = recorded['camera_quaternion'].copy()
        return values

    class CaptureSettledYaw(study._MaterialSession):
        def native_evidence(self):
            arrays, meta = super().native_evidence()
            # This callback first executes after all 1,000 decisions.
            recorded['initial_native_quaternion'] = arrays['object_quaternion_wxyz'][0].tolist()
            return arrays, meta

    def make_policy(name, kinematics):
        if name != controller:
            raise ValueError('Unexpected benchmark policy.')
        return policy

    with patch.object(piper_task, 'build_task_model', build_rotated_model), \
            patch.object(study, '_MaterialSession', CaptureSettledYaw), \
            patch.object(study, '_observe', observe), \
            patch.object(tracker, 'estimate_pose', capture_estimate), \
            patch.object(frozen, 'make_policy', make_policy):
        result = study.run_attempt(args.assets, physics_case, controller,
                                    calibration=args.calibration, trace=False,
                                    action_log=output/(case['id']+'-'+controller+'-actions.f64.zlib'))
    camera = recorded.get('camera_quaternion')
    native = recorded.get('initial_native_quaternion')
    if native is not None:
        recorded['settled_native_yaw_deg'] = yaw_degrees(native)
    if camera is not None:
        recorded['camera_yaw_deg'] = yaw_degrees(camera)
    if native is not None and camera is not None:
        recorded['camera_yaw_error_mod90_deg'] = abs((yaw_degrees(camera)-yaw_degrees(native)+45.) % 90. - 45.)
    recorded['registered_initial_yaw_deg'] = scene_yaw
    result['yaw_diagnostic'] = recorded
    result['yaw_adapter_decision'] = policy.yaw_diagnostics
    result['yaw_adapter_refusal_reason'] = policy.refusal_reason
    result['learned_artifact_sha256'] = digest(args.model)
    result['learned_policy_source_sha256'] = digest(args.policy_source)
    result['yaw_plan_sha256'] = digest(args.plan)
    result['yaw_driver_sha256'] = digest(__file__)
    result['yaw_adapter_sha256'] = digest(Path(__file__).with_name('adapter.py'))
    return result


def summarize(rows):
    placed = [row for row in rows if row['success']]
    completed = [row for row in rows if row['status'] == 'completed']
    yaw_errors = [row['yaw_diagnostic']['camera_yaw_error_mod90_deg']
                  for row in completed if 'camera_yaw_error_mod90_deg' in row['yaw_diagnostic']]
    peaks = [max(row['peak_pad_force_n'].values()) for row in completed]
    return dict(
        attempts=len(rows), completed=len(completed), strict_successes=len(placed),
        critical_contact_episodes=sum(row['critical_contact_native_ticks'] > 0 for row in completed),
        max_peak_pad_force_n=max(peaks, default=None),
        median_peak_pad_force_n=median(peaks) if peaks else None,
        median_success_time_s=median(row['first_success_time_s'] for row in placed) if placed else None,
        median_success_xy_error_mm=median(1000 * row['final_xy_error_m'] for row in placed) if placed else None,
        median_camera_yaw_error_deg=median(yaw_errors) if yaw_errors else None,
        max_camera_yaw_error_deg=max(yaw_errors, default=None),
        median_loop_p95_ms=median(row['control_loop_wall']['p95_ms'] for row in completed) if completed else None,
    )


def main():
    cli = argparse.ArgumentParser()
    for key in ('plan', 'assets', 'calibration', 'output', 'model', 'policy_source'):
        cli.add_argument('--'+key, type=Path, required=True)
    args = cli.parse_args()
    plan = json.loads(args.plan.read_text())
    expected = {
        'workspace_calibration_sha256': args.calibration,
        'model_sha256': args.model,
        'learned_policy_source_sha256': args.policy_source,
        'driver_sha256': __file__,
        'yaw_adapter_sha256': Path(__file__).with_name('adapter.py'),
    }
    for key, path in expected.items():
        if digest(path) != plan[key]:
            raise ValueError(f'Source changed since registration: {key}')
    if len(set(c['id'] for c in plan['cases'])) != len(plan['cases']):
        raise ValueError('Case IDs must be unique')
    args.policy_class = load_policy(args.policy_source)
    args.output.mkdir(exist_ok=False)
    receipt_index = []
    results = {controller: [] for controller in plan['controllers']}
    for case in plan['cases']:
        for controller in plan['controllers']:
            result = run(args, case, controller, args.output)
            results[controller].append(result)
            path = args.output/(case['id']+'-'+controller+'.json')
            with path.open('x') as f:
                json.dump(result,f,indent=2,sort_keys=True,allow_nan=False)
                f.write('\n')
            receipt_index.append({'file':path.name, 'sha256':digest(path),
                                  'success':result['success'], 'status':result['status']})
            print(path.name,result['status'],result['success'],result['reason'],flush=True)
    (args.output/'index.json').write_text(json.dumps(receipt_index, indent=2)+'\n')
    stats = {controller: summarize(rows) for controller, rows in results.items()}
    fixed, adaptive = [results[controller] for controller in plan['controllers']]
    stats['paired'] = dict(
        adaptive_only=sum(a['success'] and not f['success'] for f, a in zip(fixed, adaptive)),
        fixed_only=sum(f['success'] and not a['success'] for f, a in zip(fixed, adaptive)),
        both=sum(f['success'] and a['success'] for f, a in zip(fixed, adaptive)),
        neither=sum(not f['success'] and not a['success'] for f, a in zip(fixed, adaptive)),
    )
    (args.output/'summary.json').write_text(json.dumps(stats, indent=2, sort_keys=True, allow_nan=False)+'\n')
    print(json.dumps(stats, sort_keys=True), flush=True)
    return int(any(row['status'] in ('error', 'interrupted') for rows in results.values() for row in rows))


if __name__ == '__main__':
    raise SystemExit(main())
