"""Build the local yaw skill archive with the unchanged trained weights."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import numpy as np


ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / 'package'
members = {}


def add(source, destination):
    members[destination] = source.read_bytes()


for name in ('README.md', 'MODEL_CARD.md', 'DATA_CARD.md', 'LICENSE', 'run_yaw.py',
             'adapter.py', 'policy.py', 'model/camera-xy-primitive.npz', 'evidence/INDEX.md'):
    add(PACKAGE / name, name)
for name in ('REPORT.md', 'protocol.json', 'geometry.json', 'replay.json', 'adapted-fixtures.npz'):
    add(ROOT / name, 'evidence/' + name)
for name in ('summary.json', 'index.json'):
    add(ROOT / 'development' / name, 'evidence/' + name)
with np.load(ROOT / 'adapted-fixtures.npz', allow_pickle=False) as fixture:
    sample = []
    for step, observation in enumerate(fixture['observations'][0][:3]):
        inputs = dict(t_seconds=float(observation[0]), joint_position_rad=observation[1:].tolist(),
                      goal_position_world_m=fixture['goal_position'][0].tolist())
        if step == 0:
            inputs['initial_object_position_world_m'] = fixture['camera_position'][0].tolist()
            inputs['initial_object_quaternion_world_wxyz'] = fixture['camera_quaternion'][0].tolist()
        sample.append(json.dumps(inputs, sort_keys=True, allow_nan=False))
    members['example-observations.jsonl'] = ('\n'.join(sample) + '\n').encode()
    expected = [dict(joint_targets_rad=r[:6].tolist(), gripper_position_m=float(r[6]))
                for r in fixture['targets'][0][:3]]
    members['example-targets.jsonl'] = ('\n'.join(json.dumps(r) for r in expected) + '\n').encode()
version = '0.1.0-yaw'
model = 'model/camera-xy-primitive.npz'
manifest = dict(
    schema='dvidia.piper-yaw-placement-bundle/v1', version=version, model=model,
    base_model_sha256='aa0e1cc395954099fae954a479aa703b6cc0062a10d2ac5bed9390b96ab45c00',
    base_bundle_sha256='5aeeffd464a4bd8627617b8c6de607622663245407054f94e248895e5aef3480',
    clock_period_s=.02, simulated_horizon_s=20., physical_robot_ready=False,
    members_sha256={name: sha256(data).hexdigest() for name, data in sorted(members.items())})
if manifest['members_sha256'][model] != manifest['base_model_sha256']:
    raise ValueError('Package weights differ from the originally fitted model.')
members['manifest.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
archive = ROOT / 'piper-camera-yaw-skill-0.1.0.zip'
with ZipFile(archive, 'x', compression=ZIP_DEFLATED, compresslevel=6) as stream:
    for name, data in sorted(members.items()):
        entry = ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        entry.compress_type = ZIP_DEFLATED
        entry.external_attr = 0o100644 << 16
        stream.writestr(entry, data, compresslevel=6)
print(archive.name, archive.stat().st_size, sha256(archive.read_bytes()).hexdigest())
