"""Export adapted input/target fixtures using exact headless native replay."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from unittest.mock import patch

import numpy as np

from dvidia_training import piper_task
from dvidia_training.piper_feedback_env import FeedbackPiperTaskEnv
from dvidia_training.piper_first_attempt_replay import read_actions

from verify_replay import scene_builder


def row_for_case(assets, path, case):
    receipt = json.loads(path.read_text())
    if not receipt['valid'] or not receipt['success'] or receipt['case']['id'] != case['id']:
        raise ValueError(f'Expected the registered successful adapted receipt for {case["id"]}.')
    targets = read_actions(path.parent, receipt['action_log'])
    config = piper_task.PiperTaskConfig(
        timeout_s=20., object_position_m=case['object_position_m'],
        target_position_m=case['goal_position_m'], mass_kg=case['mass_kg'], friction=case['friction'])
    environment = FeedbackPiperTaskEnv(assets, config)
    builder = scene_builder(case['yaw_degrees'], piper_task.build_task_model)
    with patch.object(piper_task, 'build_task_model', builder):
        state, info = environment.reset(case['seed'])
    observations = np.empty((len(targets), 7))
    for index, row in enumerate(targets):
        observations[index] = [environment.elapsed, *state['joint_position_rad']]
        state, info = environment.step(dict(joint_targets_rad=row[:6].tolist(),
                                           gripper_position_m=float(row[6])))
        if not info['valid']:
            raise ValueError(f'Invalid replay at step {index} for {case["id"]}.')
    return dict(
        observations=observations, targets=targets, receipt_sha256=sha256(path.read_bytes()).hexdigest(),
        camera_position=receipt['initial_tracker']['object_position_world_m'],
        camera_quaternion=receipt['yaw_diagnostic']['camera_quaternion'],
        goal_position=case['goal_position_m'], case_id=case['id'],
    )


def main():
    cli = ArgumentParser(description=__doc__)
    for argument in ('assets', 'plan', 'receipts', 'output'):
        cli.add_argument('--' + argument, type=Path, required=True)
    args = cli.parse_args()
    cases = json.loads(args.plan.read_text())['cases']
    rows = [row_for_case(args.assets, args.receipts / (c['id'] + '-learned_camera_yaw.json'), c) for c in cases]
    arrays = {key: np.asarray([row[key] for row in rows]) for key in rows[0]}
    with args.output.open('xb') as stream:
        np.savez_compressed(stream, **arrays)
    print(f'{len(rows)} exact verification fixtures exported.')


if __name__ == '__main__':
    main()
