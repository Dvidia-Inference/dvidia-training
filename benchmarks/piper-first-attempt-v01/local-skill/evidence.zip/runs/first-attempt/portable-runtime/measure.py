"""Benchmark the unmodified yaw skill archive through pipes and a preloaded worker."""
import argparse
from hashlib import sha256
import importlib.util
import json
import os
from pathlib import Path
import platform
import resource
import subprocess
import sys
import tempfile
import time
from zipfile import ZipFile


def load_entry(root):
    spec=importlib.util.spec_from_file_location('local_skill_entry',root/'run_yaw.py')
    entry=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(entry)
    return entry


def preloaded_worker(root):
    entry=load_entry(root)
    controller=entry.Bundle().controller()
    print('READY',flush=True)
    for line in sys.stdin:
        if line.strip():
            packet=json.loads(line,object_pairs_hook=entry.unique_object)
            print(json.dumps(entry.predict(controller,packet),allow_nan=False),flush=True)


def quantiles(values):
    import numpy as np
    q=np.percentile(values,[50,95,99])
    return dict(n=len(values),p50_ms=float(q[0]),p95_ms=float(q[1]),p99_ms=float(q[2]),
                maximum_ms=float(max(values)),over_20ms=int(np.sum(np.asarray(values)>20.)))


def measure(bundle,output,environment):
    import numpy as np
    training_python=sys.executable
    invocation=Path(__file__).resolve()
    with tempfile.TemporaryDirectory(prefix='piper-portable-latency-') as directory:
        root=Path(directory)
        with ZipFile(bundle) as archive:
            if any(Path(n).is_absolute() or '..' in Path(n).parts for n in archive.namelist()):
                raise ValueError('Unexpected archive member path')
            archive.extractall(root)
        with np.load(root/'evidence/adapted-fixtures.npz',allow_pickle=False) as f:
            observations=f['observations'];target=f['targets']
            coords=f['camera_position'];quats=f['camera_quaternion'];goals=f['goal_position']
        rows=[]
        for mode in ('cli_from_process_launch','worker_preloaded'):
            cold=[];first=[];warm=[];matched=0
            for n in range(len(observations)):
                command=([training_python,'-I',str(root/'run_yaw.py')] if mode=='cli_from_process_launch'
                         else [training_python,'-I',str(invocation),'--worker',str(root)])
                start=time.perf_counter_ns()
                proc=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                                      text=True,bufsize=1,cwd=root,env=environment)
                if mode=='worker_preloaded':
                    if proc.stdout.readline().strip()!='READY':
                        raise RuntimeError(proc.stderr.read())
                    cold.append((time.perf_counter_ns()-start)/1e6)
                for tick,row in enumerate(observations[n]):
                    packet=dict(t_seconds=float(row[0]),joint_position_rad=row[1:].tolist(),
                        goal_position_world_m=goals[n].tolist())
                    if tick==0:
                        packet.update(initial_object_position_world_m=coords[n].tolist(),
                            initial_object_quaternion_world_wxyz=quats[n].tolist())
                    begin=time.perf_counter_ns()
                    proc.stdin.write(json.dumps(packet,separators=(',',':'))+'\n')
                    proc.stdin.flush()
                    reply=proc.stdout.readline()
                    if not reply:
                        raise RuntimeError(proc.stderr.read())
                    action=json.loads(reply)
                    finish=time.perf_counter_ns()
                    if not np.array_equal([*action['joint_targets_rad'],action['gripper_position_m']],target[n,tick]):
                        raise ValueError(f'Unexpected command {mode} {n} {tick}')
                    matched+=1
                    latency=(finish-begin)/1e6
                    if tick==0:
                        first.append(latency)
                        if mode=='cli_from_process_launch':
                            cold.append((finish-start)/1e6)
                    else:
                        warm.append(latency)
                proc.stdin.close()
                if proc.wait()!=0:
                    raise RuntimeError(proc.stderr.read())
            rows.append(dict(mode=mode,cold_process_to_first_or_ready=quantiles(cold),first_query=quantiles(first),
                             subsequent_queries=quantiles(warm),exact_targets=matched))
    peak=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    bytes_rss=int(peak if sys.platform=='darwin' else peak*1024)
    result=dict(schema='dvidia.piper-portable-runtime/v1',bundle_sha256=sha256(bundle.read_bytes()).hexdigest(),
        measure_sha256=sha256(invocation.read_bytes()).hexdigest(),host=dict(platform=platform.platform(),architecture=platform.machine(),
        python=platform.python_version(),numpy=np.__version__,thread_caps=['OPENBLAS_NUM_THREADS=1','VECLIB_MAXIMUM_THREADS=1','OMP_NUM_THREADS=1']),
        runs=rows,peak_child_resident_bytes=bytes_rss,peak_child_mib=bytes_rss/1024**2,
        scope='Single local worker, synchronous JSONL pipes, per-request serialization and response parsing included. OS file cache/shared-host state uncontrolled. Ready handshake is in the benchmark wrapper and uses the same bundle controller. Camera, physics and actuators excluded.')
    output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps(result,sort_keys=True))


def main():
    cli=argparse.ArgumentParser()
    cli.add_argument('--worker',type=Path)
    cli.add_argument('--bundle',type=Path)
    cli.add_argument('--output',type=Path)
    args=cli.parse_args()
    if args.worker is not None:
        return preloaded_worker(args.worker)
    env=os.environ.copy()
    env.update(OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    if args.output.exists():
        raise ValueError('Choose a fresh result path')
    measure(args.bundle,args.output,env)


if __name__=='__main__':
    main()
