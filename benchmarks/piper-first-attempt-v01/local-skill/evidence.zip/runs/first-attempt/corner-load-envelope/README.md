# PiPER corner-grip load envelope

This development-only sweep ran the unchanged frozen corner-v8 controller on
40 registered episodes. It used the two existing development starts
development-00-g0 and development-03-g0, goal A, the surveyed nominal
calibration, and the existing 1 ms native physics scorer. Each mass/friction
cell has two attempts. The complete roster and plan are retained beside the
receipts.

The static proxy was preregistered as

mu * 40 N/m * (0.020 * sqrt(2) m) >= mass * 9.81 m/s²

This is an idealized friction/load proxy. It was not passed to the controller
and does not replace native contact dynamics.

| Mass (kg) / friction | 0.35 | 0.55 | 0.75 | 0.95 |
| --- | --- | --- | --- | --- |
| 0.025 | 2/2 | 2/2 | 2/2 | 2/2 |
| 0.040 | 0/2 | 2/2 | 2/2 | 2/2 |
| 0.055 | 0/2 | 2/2 | 2/2 | 2/2 |
| 0.070 | 0/2 | 0/2 | 2/2 | 2/2 |
| 0.085 | 0/2 | 0/2 | 0/2 | 2/2 |

Cells show strict placements out of two attempts. Every failed attempt failed
at the native lift stage. There were zero critical-contact episodes. Native
lift_seen matched the strict result for all 40 attempts.

The static inequality predicted 26 successful lifts correctly and produced
10 true negatives. All four false positives occurred at two settings,
0.040 kg with friction 0.35 and 0.085 kg with friction 0.75. Each setting
was tested at both starting positions. There were zero false negatives.

All results are local simulation evidence for one known rigid cube, two
development starts and one goal. They do not qualify hardware, unseen objects,
or general load handling.
