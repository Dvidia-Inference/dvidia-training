"""Matched causal finger-encoder monitors on offline, open-loop PiPER replays."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import time
import zlib

import numpy as np

from dvidia_training.piper_feedback_env import FeedbackPiperTaskEnv, JawPulse
from dvidia_training.piper_task import PiperTaskConfig


def digest(p):
    return sha256(p.read_bytes()).hexdigest()


def write(p,d):
    with p.open('x') as f:
        json.dump(d,f,indent=2,sort_keys=True,allow_nan=False)
        f.write('\n')


def control_tape(receipt_path,receipt):
    binding=receipt['action_log']
    name=Path(binding['path'])
    if name.name!=str(name) or binding['shape']!=[1000,7]:
        raise ValueError('Invalid actuator tape binding')
    path=receipt_path.parent/name
    if path.stat().st_size>65536 or digest(path)!=binding['sha256']:
        raise ValueError('Tape digest mismatch')
    buf=zlib.decompress(path.read_bytes())
    if len(buf)!=56000:
        raise ValueError('Invalid actuator tape length')
    return np.frombuffer(buf,dtype='<f8').reshape(1000,7)


def replay(assets, receipt_path, pulse):
    r=json.loads(receipt_path.read_text()); case=r['case']
    actions=control_tape(receipt_path,r)
    config=PiperTaskConfig(object_position_m=case['object_position_m'],
        target_position_m=case['goal_position_m'],mass_kg=case['mass_kg'],friction=case['friction'])
    pulses=() if pulse is None else (JawPulse(*pulse),)
    env=FeedbackPiperTaskEnv(assets,config,pulses=pulses)
    obs,info=env.reset(case['seed'])
    fingers=np.empty((1000,2))
    for i,row in enumerate(actions):
        fingers[i]=[obs['gripper_joint_position_m'][0],-obs['gripper_joint_position_m'][1]]
        obs,info=env.step(dict(joint_targets_rad=row[:6].tolist(),gripper_position_m=float(row[6])))
        if obs is None or not info['valid']:
            raise ValueError(f'Invalid native replay at {i}')
    if pulse is None:
        if (r['success']!=bool(info['success'])
                or not np.allclose(r['final_object_position_m'],obs['object_position_m'],atol=1e-9,rtol=0)):
            raise ValueError('Clean replay differs from source receipt')
    return r,actions,fingers,env,info


def consecutive(mask,n):
    runs=np.convolve(mask.astype(int),np.ones(n,dtype=int),mode='valid')
    return np.flatnonzero(runs==n)+n-1


def native_loss(env,case):
    arrays=env.native_arrays()
    both=np.all(arrays['grasp_contact_counts']>0,axis=1)
    held=(both & (arrays['table_object_contact_count']==0)
          & (arrays['object_position_m'][:,2]-env.initial_object_position[2]>=.06))
    stable=consecutive(held,100)
    if not len(stable):
        return None
    after=stable[0]
    supported=(both & (arrays['table_object_contact_count']>0)
               & (np.linalg.norm(arrays['object_position_m']-case['goal_position_m'],axis=1)<=.025))
    placed=np.flatnonzero(supported[after:])
    end=after+int(placed[0]) if len(placed) else len(both)
    confirmed=consecutive(~both[after:end],40) if end-after>=40 else []
    measured=float(arrays['t_seconds'][after+confirmed[0]]) if len(confirmed) else None
    if bool(env.retention_lost)!=bool(measured):
        raise ValueError('Independent native event reconstruction disagrees with original scorer.')
    return measured


def fit(assets,source,out):
    samples=[[],[]]
    commands=[[],[]]
    manifest=[]
    for p in sorted((source/'teacher').glob('attempt-????.json')):
        r,actions,fingers,env,_=replay(assets,p,None)
        if not r['success']:
            raise ValueError('Expected the already verified 32 successful source trajectories.')
        g=r['case']['goal_id']
        samples[g].append(fingers);commands[g].append(actions[:,6])
        manifest.append(dict(source=r['case']['id'],receipt_sha256=digest(p),
                         command_sha256=r['action_log']['sha256']))
    if any(len(g)!=16 for g in samples):
        raise ValueError('Need exactly 16 training trajectories per goal.')
    start=time.perf_counter()
    sensors=np.asarray(samples); jaws=np.asarray(commands)
    inside=np.all((sensors>=.024)&(sensors<=.032),axis=3) & (jaws<=.004)
    stable=inside.sum(axis=1)>=15
    enable=np.zeros((2,1000),dtype=bool)
    for g in range(2):
        enable[g,consecutive(stable[g],5)]=True
    model=dict(low=np.min(sensors,axis=1),high=np.max(sensors,axis=1),enabled=enable)
    elapsed=time.perf_counter()-start
    np.savez_compressed(out/'finger-envelope.npz',**model)
    write(out/'fit.json',dict(algorithm='per-goal/time extrema plus 0.75mm margin',
        fit_compute_s=elapsed,training=manifest,sensor_samples=32000,
        model_sha256=digest(out/'finger-envelope.npz'),enabled_ticks_per_goal=enable.sum(axis=1).tolist()))
    return model


class Monitor:
    def __init__(self,model,goal,learned):
        self.low=model['low'][goal];self.high=model['high'][goal];self.enable=model['enabled'][goal]
        self.learned=learned;self.streak=0

    def __call__(self,i,fingers):
        if not self.enable[i]:
            self.streak=0
            return False
        if self.learned:
            breach=np.any((fingers<self.low[i]-.00075)|(fingers>self.high[i]+.00075))
            required=3
        else:
            breach=np.any(np.abs(fingers-.020*np.sqrt(2.))>.006)
            required=4
        self.streak=self.streak+1 if breach else 0
        return self.streak>=required


def main():
    cli=argparse.ArgumentParser()
    for name in ('plan','source','assets','output'):
        cli.add_argument('--'+name,required=True,type=Path)
    args=cli.parse_args()
    plan=json.loads(args.plan.read_text())
    args.output.mkdir(exist_ok=False)
    if digest(args.source/'model/camera-xy-primitive.npz')!=plan['source_learner_sha256']:
        raise ValueError('Source learned model changed.')
    model=fit(args.assets,args.source,args.output)
    rows=[]
    for group in (3,4,5):
        for goal in (0,1):
            case=f'development-{group:02}-g{goal}'
            path=args.source/'development'/(case+'-learned.json')
            for pulse in plan['pulses']:
                r,_,fingers,env,info=replay(args.assets,path,pulse)
                truth=native_loss(env,r['case'])
                outcomes={}
                for name in ('wide','learned'):
                    monitor=Monitor(model,goal,name=='learned')
                    times=[];first=None
                    for index,v in enumerate(fingers):
                        start=time.perf_counter_ns()
                        warning=monitor(index,v)
                        times.append(time.perf_counter_ns()-start)
                        if warning and first is None:
                            first=.02*index
                    outcomes[name]=dict(first_warning_s=first,
                        signed_delay_s=None if first is None or truth is None else first-truth,
                        warning_before_pulse=bool(pulse and first is not None and first<pulse[0]),
                        p95_decision_us=float(np.percentile(times,95))/1000.)
                rows.append(dict(case_id=case,pulse=pulse,strict_success=bool(info['success']),
                         retention_loss_confirmed_s=truth,critical_ticks=int(env.critical_contact_ticks),
                         outputs=outcomes))
                print(case,pulse,truth,{n:v['first_warning_s'] for n,v in outcomes.items()},flush=True)
    write(args.output/'results.json',dict(plan_sha256=digest(args.plan),driver_sha256=digest(Path(__file__)),
        schema='dvidia.piper-grip-monitor-development/v1',attempts=rows))


if __name__=='__main__':
    main()
