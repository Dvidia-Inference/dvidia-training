"""Render one exact learned command tape from two views of the same native scene."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zlib

import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from dvidia_training.piper_feedback_env import FeedbackPiperTaskEnv
from dvidia_training.piper_task import PiperTaskConfig


def font(size, bold=False):
    paths = [
        Path('/System/Library/Fonts/Supplemental') / ('Arial Bold.ttf' if bold else 'Arial.ttf'),
        Path('/usr/share/fonts/truetype/dejavu') / ('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf'),
    ]
    for path in paths:
        if path.is_file():
            return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default(size=size)


def panel_camera(lookat, distance, azimuth, elevation):
    cam = mujoco.MjvCamera()
    cam.lookat[:] = lookat
    cam.distance, cam.azimuth, cam.elevation = distance, azimuth, elevation
    return cam


def main():
    cli = argparse.ArgumentParser()
    for name in ('assets','receipt','output'):
        cli.add_argument('--'+name, type=Path, required=True)
    args = cli.parse_args()
    args.output.mkdir(exist_ok=False)
    receipt = json.loads(args.receipt.read_text())
    case, binding = receipt['case'], receipt['action_log']
    name = Path(binding['path'])
    if name.name != str(name) or binding['shape'] != [1000,7]:
        raise ValueError('Invalid action tape layout.')
    tape = (args.receipt.parent/name).read_bytes()
    if len(tape)>65536 or sha256(tape).hexdigest()!=binding['sha256']:
        raise ValueError('Unexpected compressed action tape.')
    raw = zlib.decompress(tape)
    if len(raw)!=56000:
        raise ValueError('Unexpected action vector byte count.')
    actions = np.frombuffer(raw,dtype='<f8').reshape(1000,7)
    config = PiperTaskConfig(object_position_m=case['object_position_m'],
        target_position_m=case['goal_position_m'],mass_kg=case['mass_kg'],friction=case['friction'])
    env = FeedbackPiperTaskEnv(args.assets,config)
    observation,info = env.reset(case['seed'])
    # These reporting views share the exact task dynamics and use fill light
    # solely for legibility. The recorded policy inputs are unchanged.
    headlight=env.model.vis.headlight
    headlight.active=1
    headlight.ambient[:]=[.55,.55,.55]
    headlight.diffuse[:]=[.65,.65,.65]
    headlight.specular[:]=[.20,.20,.20]
    env.model.vis.global_.offwidth=max(env.model.vis.global_.offwidth,624)
    env.model.vis.global_.offheight=max(env.model.vis.global_.offheight,420)
    views = [
        panel_camera([.21,-.005,.22],.88,112.,-34.),
        panel_camera([.33,.015,.12],.38,120.,-56.),
    ]
    renderer=mujoco.Renderer(env.model,height=420,width=624)
    title, normal, small=font(34,True),font(23),font(18)
    mp4=args.output/'learned-piper-placement.mp4'
    proc=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x610','-r','25','-i','-','-an',
        '-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(mp4)],stdin=subprocess.PIPE)
    initial=np.asarray(observation['object_position_m'])
    frame_count=0
    try:
        for i,row in enumerate(actions):
            if i%4==0:
                canvas=Image.new('RGB',(1280,610),'#f6f5ef')
                draw=ImageDraw.Draw(canvas)
                draw.text((20,12),'PiPER block placement',font=title,fill='#192723')
                draw.text((21,58),'Learned from 32 simulated demonstrations',font=normal,fill='#44554f')
                draw.text((1000,22),'Simulation replay · 2×',font=normal,fill='#44554f')
                for x,cam in zip([12,644],views):
                    renderer.update_scene(env.data,camera=cam)
                    canvas.paste(Image.fromarray(renderer.render()),(x,103))
                draw.text((18,526),'Arm view',font=small,fill='#44554f')
                draw.text((650,526),'Object and destination',font=small,fill='#44554f')
                xyz=np.asarray(observation['object_position_m'])
                height=max(0.,(xyz[2]-initial[2])*1000.)
                error=np.linalg.norm(xyz[:2]-np.array(config.target_position_m[:2]))*1000.
                if env.first_success_time is not None:
                    state='Placement verified'
                elif env.carry_complete:
                    state='Supported at destination'
                elif env.lift_seen:
                    state='Sustained lift verified'
                elif env.grasp_seen:
                    state='Bilateral contact'
                else:
                    state='Approach'
                draw.text((18,561),f'{i*.02:05.2f} s   ·   {state}',font=normal,fill='#183d31')
                draw.text((647,561),f'Cube lift  {height:.0f} mm       XY error  {error:.0f} mm',font=normal,fill='#183d31')
                proc.stdin.write(canvas.tobytes())
                if i in (0,500):
                    canvas.save(args.output/f'frame-{i:04}.jpg',quality=90)
                frame_count+=1
            action={'joint_targets_rad':row[:6].tolist(),'gripper_position_m':float(row[6])}
            observation,info=env.step(action)
            if observation is None or not info['valid']:
                raise RuntimeError('Native physics invalid during replay.')
    finally:
        renderer.close()
        proc.stdin.close()
        if proc.wait()!=0:
            raise RuntimeError('Video encoder failed.')
    native=env.native_arrays()
    peak=float(native['pad_normal_forces_n'].max())
    assert receipt['success'] == bool(info['success'])
    assert np.allclose(native['object_position_m'][-1],receipt['final_object_position_m'],atol=1e-9,rtol=0.)
    assert abs(peak-max(receipt['peak_pad_force_n'].values()))<1e-9
    assert abs(env.first_success_time-receipt['first_success_time_s'])<1e-9
    assert env.critical_contact_ticks==receipt['critical_contact_native_ticks']
    result=dict(case_id=case['id'],source_receipt_sha256=sha256(args.receipt.read_bytes()).hexdigest(),
        exact_command_tape_sha256=binding['sha256'],video_sha256=sha256(mp4.read_bytes()).hexdigest(),frame_count=frame_count,
        fps=25,simulated_s=20.,playback_speed=2.,peak_pad_force_n=peak,first_success_sim_s=env.first_success_time,
        critical_ticks=env.critical_contact_ticks,strict_success=bool(info['success']),
        scope='Two rendered views of native physics replaying one recorded learned action tape. Fill light is for display. Overlays use post-hoc native state.')
    (args.output/'render-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__=='__main__':
    main()
