# PiPER placement skill with camera yaw

This local research skill turns time-stamped simulated PiPER observations into six joint targets and one gripper target every 20 ms. The trained model and input frame match the base DVIDIA PiPER placement experiment. The yaw adapter uses the first RGB-D quaternion to align the gripper with the diagonal of a known upright 40 mm cube.

## Run locally

Extract the archive and use Python 3.12 with NumPy 2.5.3 installed. Inference uses only Python and NumPy. It reads newline-delimited JSON and writes requested simulated targets to stdout.

```sh
python -I run_yaw.py < example-observations.jsonl
python -I run_yaw.py --self-test
```

The runner resolves its versioned model relative to the extracted files. It checks the model and both policy source digests before running. The self-test checks all archive members and compares 24 adapted rollouts with their exact saved commands.

Start a fresh process per episode. The first observation has all five fields shown in the example. Include only the timestamp, destination and measured joint positions thereafter. Supply measured encoders in PiPER joint order and radians. Positions use metres in the surveyed simulation world, and the initial quaternion uses the normalized upright `[w, x, y, z]` convention. Timestamps start at zero and advance by 0.02 seconds per observation, for up to 1,000 observations. Destination is either `[0.35, 0.08, 0.08]` or `[0.40, -0.08, 0.08]` throughout the episode.

The output target values use radians and metres. The local runner has no real-arm interface. A simulation integration must supply synchronized initial RGB-D estimates and measured joints, execute at the 50 Hz clock, and enforce the native actuator slew limits.

[Model card](MODEL_CARD.md) · [Data card](DATA_CARD.md) · [Development report](evidence/REPORT.md) · [Evidence index](evidence/INDEX.md)
