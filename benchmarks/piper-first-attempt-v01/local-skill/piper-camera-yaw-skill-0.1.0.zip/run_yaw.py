"""Offline simulated PiPER target inference from one camera pose and encoders."""
import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
import math
from pathlib import Path
import sys

import numpy as np


ROOT = Path(__file__).resolve().parent
VERSION = '0.1.0-yaw'
MODEL = 'model/camera-xy-primitive.npz'
MODEL_SHA256 = 'aa0e1cc395954099fae954a479aa703b6cc0062a10d2ac5bed9390b96ab45c00'
SAMPLE_KEYS = {'t_seconds', 'joint_position_rad', 'goal_position_world_m'}
INITIAL_KEYS = {'initial_object_position_world_m', 'initial_object_quaternion_world_wxyz'}
MAX_LINE_BYTES = 16_384


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def check_file(manifest, location):
    path = (ROOT / location).resolve()
    if not path.is_relative_to(ROOT) or digest(path) != manifest['members_sha256'][location]:
        raise ValueError(f'Skill bundle digest mismatch for {location}.')


def load_member(name):
    spec = spec_from_file_location(name, ROOT / (name + '.py'))
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Bundle:
    def __init__(self):
        self.manifest = json.loads((ROOT / 'manifest.json').read_text())
        if self.manifest['version'] != VERSION or self.manifest['model'] != MODEL:
            raise ValueError('Unsupported skill bundle version or model layout.')
        for location in ('adapter.py', 'policy.py', MODEL):
            check_file(self.manifest, location)
        if self.manifest['members_sha256'][MODEL] != MODEL_SHA256:
            raise ValueError('Model differs from the registered learned artifact.')
        self.policy_module = load_member('policy')
        self.adapter_module = load_member('adapter')

    def controller(self):
        base = self.policy_module.Policy(ROOT / MODEL)
        return self.adapter_module.InitialYawPolicy(base, adaptive=True)


def finite_number(value):
    return type(value) in (int, float) and math.isfinite(value)


def vector(observation, name, size):
    values = observation[name]
    if type(values) is not list or len(values) != size or not all(map(finite_number, values)):
        raise ValueError(f'Require {size} finite numeric components for {name}.')


def predict(policy, observation):
    initial = policy.base.index == 0
    expected = SAMPLE_KEYS | INITIAL_KEYS if initial else SAMPLE_KEYS
    if type(observation) is not dict or set(observation) != expected:
        raise ValueError('Unexpected observation keys for the current decision.')
    if not finite_number(observation['t_seconds']):
        raise ValueError('Require finite simulation time.')
    vector(observation, 'joint_position_rad', 6)
    vector(observation, 'goal_position_world_m', 3)
    if initial:
        vector(observation, 'initial_object_position_world_m', 3)
        vector(observation, 'initial_object_quaternion_world_wxyz', 4)
        x, y, z = observation['initial_object_position_world_m']
        if not (.284 <= x <= .314 and -.045 <= y <= -.015 and .075 <= z <= .085):
            raise ValueError('Initial camera position is outside the registered work surface.')
    return policy(observation)


def self_test(bundle):
    for member in bundle.manifest['members_sha256']:
        check_file(bundle.manifest, member)
    with np.load(ROOT / 'evidence/adapted-fixtures.npz', allow_pickle=False) as fixture:
        cases, observations, targets = fixture['case_id'], fixture['observations'], fixture['targets']
        if len(cases) != 24 or observations.shape != (24, 1000, 7) or targets.shape != (24, 1000, 7):
            raise ValueError('Expected all 24 registered adapted input/target tapes.')
        positions, quaternions, goals = fixture['camera_position'], fixture['camera_quaternion'], fixture['goal_position']
        for case, (position, quaternion, goal, samples, expected) in enumerate(
                zip(positions, quaternions, goals, observations, targets, strict=True)):
            policy = bundle.controller()
            for step, sample in enumerate(samples):
                observation = dict(t_seconds=float(sample[0]), joint_position_rad=sample[1:].tolist(),
                                   goal_position_world_m=goal.tolist())
                if step == 0:
                    observation.update(initial_object_position_world_m=position.tolist(),
                                       initial_object_quaternion_world_wxyz=quaternion.tolist())
                answer = predict(policy, observation)
                command = [*answer['joint_targets_rad'], answer['gripper_position_m']]
                if not np.array_equal(command, expected[step]):
                    raise RuntimeError(f'Inference did not match {cases[case]} at step {step}.')
    return dict(version=VERSION, exact_tapes=24, exact_command_vectors=24_000,
                manifest_members=len(bundle.manifest['members_sha256']))


def unique_object(pairs):
    result = dict(pairs)
    if len(result) != len(pairs):
        raise ValueError('Repeated keys in JSON observation.')
    return result


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--version', action='version', version=VERSION)
    cli.add_argument('--self-test', action='store_true', help='Check the bundled 24 adapted command tapes.')
    args = cli.parse_args()
    try:
        bundle = Bundle()
        if args.self_test:
            print(json.dumps(self_test(bundle), sort_keys=True))
            return 0
        policy = bundle.controller()
        while line := sys.stdin.buffer.readline(MAX_LINE_BYTES + 1):
            if len(line) > MAX_LINE_BYTES:
                raise ValueError('Observation line is too long.')
            if line.strip():
                action = predict(policy, json.loads(line, object_pairs_hook=unique_object))
                print(json.dumps(action, allow_nan=False), flush=True)
    except (ValueError, TypeError, KeyError, OSError, OverflowError, RuntimeError) as error:
        cli.exit(2, f'PiPER simulation skill: {error}\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
