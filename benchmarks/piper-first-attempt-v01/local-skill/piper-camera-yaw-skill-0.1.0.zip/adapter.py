"""Apply initial observed cube yaw to a frozen learned PiPER trajectory."""
import math

import numpy as np


DT = .02
WRIST_LOW = -3.14 + .02
WRIST_HIGH = 3.14 - .02


def yaw_from_camera(quaternion):
    values = np.asarray(quaternion, dtype=float)
    if (values.shape != (4,) or not np.isfinite(values).all()
            or abs(values @ values - 1.) > 1e-6 or np.max(np.abs(values[1:3])) > 1e-5):
        raise ValueError('Require the initial upright camera quaternion.')
    return 2. * math.atan2(values[3], values[0]) % (math.pi / 2.)


def offset_wrist(reference, quaternion, initial_wrist):
    camera_yaw = yaw_from_camera(quaternion)
    closes = np.flatnonzero(reference[:, 6] < .035 / 2.)
    if not closes.size:
        raise ValueError('The learned reference contains no close event.')
    close = int(closes[0])
    ramp_steps = close - round(.30 / DT)
    if ramp_steps <= 0:
        raise ValueError('The learned reference closes before the wrist can orient.')
    fraction = np.clip(np.arange(len(reference)) / ramp_steps, 0., 1.)
    ramp = fraction**3 * (10. + fraction * (-15. + 6. * fraction))
    candidates = []
    for k in range(-2, 3):
        twist = -camera_yaw + k * math.pi / 2.
        shifted = reference[:, 5] + twist * ramp
        if np.all(shifted >= WRIST_LOW) and np.all(shifted <= WRIST_HIGH):
            travel = abs(shifted[close] - initial_wrist)
            candidates.append((travel, abs(twist), k, twist, shifted))
    if not candidates:
        raise ValueError('No equivalent diagonal stays within PiPER wrist margins.')
    travel, _, k, twist, shifted = min(candidates, key=lambda item: item[:3])
    reference[:, 5] = shifted
    return dict(camera_yaw_deg=math.degrees(camera_yaw), wrist_twist_deg=math.degrees(twist),
                predicted_full_twist_at_s=ramp_steps * DT, predicted_close_s=close * DT,
                selected_equivalent_index=k, wrist_travel_to_predicted_close_deg=math.degrees(travel))


class InitialYawPolicy:
    def __init__(self, base, *, adaptive):
        self.base = base
        self.adaptive = adaptive
        self.yaw_diagnostics = None
        self.phase = 'learned_camera_yaw' if adaptive else 'learned_fixed_yaw'
        self.refusal_reason = None

    def __call__(self, observation):
        action = self.base(observation)
        if self.adaptive and self.base.index == 1:
            try:
                self.yaw_diagnostics = offset_wrist(
                    self.base.reference, observation['initial_object_quaternion_world_wxyz'],
                    observation['joint_position_rad'][5])
            except ValueError as error:
                self.refusal_reason = str(error)
                raise
        return action
