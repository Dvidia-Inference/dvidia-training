# Data card

**Training.** Thirty-two successful synthetic demonstration episodes from the authored PiPER corner placement controller. They span 16 aligned cube starts, two task destinations and three fixed material strata. The learner fitted seven issued command targets from the initial camera XY, elapsed time and destination. The base evidence bundle carries the training data and calibration receipt.

**Verification.** `evidence/adapted-fixtures.npz` contains native simulation input and output fixtures for 24 camera-yaw-adapted development episodes. They use previously studied development starts excluded from the learned fit, at two registered yaw angles each. Each episode has 1,000 observations and commands. The verifier reconstructs observations from saved measured encoders and the tracker’s initial pose.

| Array | Contents |
|---|---|
| `observations` | Elapsed seconds followed by six measured joint positions in radians |
| `targets` | Six issued joint targets in radians followed by one finger target in metres |
| `camera_position` | Historical RGB-D estimate of block centre in metres |
| `camera_quaternion` | Historical RGB-D upright quaternion in wxyz order |
| `goal_position` | Fixed benchmark destination in metres |
| `case_id`, `receipt_sha256` | Paired source receipt identifier and digest |

The simulation fixtures supply no RGB-D pixels, camera images from people, physical-robot logs, contact flags or task labels. The separate score receipts contain simulator state and are measurement evidence for the study.

[Evidence index](evidence/INDEX.md) · [Protocol](evidence/protocol.json)
