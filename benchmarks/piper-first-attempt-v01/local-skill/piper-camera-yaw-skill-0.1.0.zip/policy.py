"""Local NumPy inference for the PiPER camera-XY research model."""
from argparse import ArgumentParser
import json
import math
from pathlib import Path
import sys

import numpy as np


DT = .02
STEPS = 1000
GOALS = np.array([[.35, .08, .08], [.40, -.08, .08]])
LOWER = np.array([-2.618, 0., -2.697, -1.832, -1.22, -3.14])
UPPER = np.array([2.618, 3.14, 0., 1.832, 1.22, 3.14])
SCALE = np.array([3.] * 6 + [.035])


def vector(value, size, name):
    result = np.asarray(value, dtype=float)
    if result.shape != (size,) or not np.isfinite(result).all():
        raise ValueError(f'Require {size} finite components for {name}.')
    return result


def time_basis():
    elapsed = np.arange(STEPS) * DT
    centers = np.linspace(0., 20., 201)
    distance = (elapsed[:, None] - centers) / .075
    logits = -.5 * distance * distance
    logits -= np.max(logits, axis=-1, keepdims=True)
    values = np.exp(logits)
    return values / values.sum(axis=-1, keepdims=True)


def spatial_basis(position):
    x, y = (position[:2] - np.array([.299, -.03])) / .015
    return np.stack((np.ones_like(x), y, y*y, x, x*y, x*y*y, x*x, x*x*y, x*x*y*y))


class Policy:
    """Create a fresh instance for each simulated 50 Hz rollout."""
    def __init__(self, model_path):
        with np.load(model_path, allow_pickle=False) as data:
            weights = data['weights']
        if weights.shape != (2, 9, 201, 7) or not np.isfinite(weights).all():
            raise ValueError('Invalid PiPER model layout.')
        self.weights = weights
        self.index = 0
        self.reference = None
        self.goal = None

    def __call__(self, observation):
        if self.index >= STEPS:
            raise ValueError('The 20-second rollout is complete.')
        t = observation['t_seconds']
        if not math.isclose(t, self.index * DT, rel_tol=0., abs_tol=1e-8):
            raise ValueError('Require simulation time beginning at zero and advancing exactly 20 ms.')
        goal = vector(observation['goal_position_world_m'], 3, 'destination')
        matches = np.flatnonzero(np.max(np.abs(GOALS - goal), axis=1) <= 1e-8)
        if len(matches) != 1:
            raise ValueError('Require one of the two known simulation destinations.')
        goal_index = int(matches[0])
        q = vector(observation['joint_position_rad'], 6, 'measured joint position')
        if np.any(q < LOWER) or np.any(q > UPPER):
            raise ValueError('Measured joint position exceeds PiPER limits.')
        if self.reference is None:
            position = vector(observation['initial_object_position_world_m'], 3, 'historical camera position')
            coefficients = np.einsum('s,stj->tj', spatial_basis(position), self.weights[goal_index])
            self.reference = (time_basis() @ coefficients) * SCALE
            self.goal = goal_index
        if self.goal != goal_index:
            raise ValueError('Destination changed within the simulated rollout.')
        row = self.reference[self.index]
        target = np.clip(q + np.clip(row[:6] - q, -.06, .06), LOWER + .02, UPPER - .02)
        self.index += 1
        return {'joint_targets_rad': target.tolist(), 'gripper_position_m': float(np.clip(row[6], 0., .035))}


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--model', type=Path, required=True)
    args = parser.parse_args()
    policy = Policy(args.model)
    for line in sys.stdin:
        if line.strip():
            print(json.dumps(policy(json.loads(line)), allow_nan=False), flush=True)


if __name__ == '__main__':
    main()
