# Adapting the learned PiPER skill to a turned block

The same learned PiPER model completed **24/24 strict simulated placements** when its wrist used yaw from the first RGB-D frame. It completed **16/24** with its nominal wrist angle. All eight gains came from rotating and lifting the 60 g block at friction coefficient 0.55, where the nominal wrist took bilateral contact but failed to sustain a lift. The two methods used the identical frozen model, surveyed camera and original simulator limits.

## What changed

The learned reference still supplies six joint targets and one gripper target from the initial block position, destination and elapsed time. The adapter adds a rotation to joint 6, which turns the gripper about the tool centreline. Robot-only forward kinematics verified the geometry on 16 configurations and joint changes. Maximum TCP position difference was 6.25×10⁻¹⁷ m, and the maximum local rotation matrix element error was 2.22×10⁻¹⁵.

The adapter chooses a square-symmetric corner grasp from the initial camera yaw. It picks the in-limit wrist rotation requiring the shortest trip from the measured starting wrist position to the predicted closure pose, then ramps the offset smoothly before closure. All other learned reference coordinates and the first issued command stay identical. The point-coordinate invariance is kinematic. Contacts, forces and actuator tracking still change under dynamics, so the strict physical outcome is independently scored at 1 ms.

## Matched development trials

| Simulated metric | Nominal learned wrist | Camera-aligned learned wrist |
|---|---:|---:|
| Strict placements | 16/24 | 24/24 |
| 30 g and 40 g blocks | 16/16 | 16/16 |
| 60 g block, friction coefficient 0.55 | 0/8 | 8/8 |
| Critical-contact episodes | 0/24 | 0/24 |
| Median completion among successes | 14.354 s | 14.3665 s |
| Median XY error among successes | 5.66 mm | 4.27 mm |
| Median per-episode peak pad force | 0.881 N | 0.709 N |
| Maximum observed pad force | 1.533 N | 1.816 N |
| Median per-episode p95 policy compute | 0.0167 ms | 0.0173 ms |
| Median per-episode p95 simulation loop | 2.03 ms | 2.01 ms |

All 48 attempts completed. Headless replay reproduced all 48 recorded command streams and outcomes. The 24 matched configurations covered six previously studied development positions, both destinations and the fixed yaw angles −32° and +24°. Across the 16 cases where both methods succeeded, the median paired completion-time difference was 0.00 s, the median paired XY error fell by 1.32 mm and the median per-episode peak force fell by 0.43 N with the adapter. The camera yaw error modulo 90° had a median of 0.50° and a maximum of 1.00°. The learned model came from demonstrations of axis-aligned cubes, and the two angles were registered before this comparison. The peak-force increase reflects the worst observed trial in one run. These results apply to the simulated upright cube, two destinations and tested material range. They do not establish arbitrary orientation, jaw slip detection, closed-loop recovery, physical transfer or performance on the separate confirmation roster.

Timing captures local NumPy work and offline simulation on the arm64 Mac. The median first render/encode took 65–74 ms across the two conditions, and median tracking took 3.5–3.7 ms. Compute timings exclude external camera and controller I/O.

## Reproduce

From the worktree, use the same training Python environment with `PYTHONPATH=src` and the pinned PiPER assets. The renderer needs an offscreen graphics context. Use a new output directory for the 48 registered attempts.

```sh
study=runs/first-attempt/corner-distilled-yaw
frozen=runs/first-attempt/corner-distillation
calibration=benchmarks/piper-first-attempt-v01/workspace/nominal.json
python "$study/driver.py" --plan "$study/protocol.json" --assets "$PIPER_ASSETS" \
  --calibration "$calibration" --model "$frozen/model/camera-xy-primitive.npz" \
  --policy_source "$frozen/policy.py" --output "$study/development-reproduction"
python "$study/verify_replay.py" --plan "$study/protocol.json" --assets "$PIPER_ASSETS" \
  --receipts "$study/development-reproduction" --output "$study/replay-reproduction.json"
```

The [registration](protocol.json) binds the driver, adapter, frozen model, policy implementation, camera calibration and all conditions. [Summary](development/summary.json), [receipt index](development/index.json), [FK checks](geometry.json), [headless replay](replay.json).
