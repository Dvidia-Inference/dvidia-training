# Research evidence

This local archive contains the preregistered yaw experiment, its report and summary, the 16 encoder-only geometric checks, and fixtures for exact evaluation of the portable policy. The original experiment did two physics trials for each registered rotated scene, with and without the adapter.

The adjacent local base package is `corner-distillation/piper-camera-xy-distillation-v1.zip`, SHA-256 `5aeeffd464a4bd8627617b8c6de607622663245407054f94e248895e5aef3480`. It carries the aligned-cube training tapes, original model card, recipe and exact no-yaw evaluation evidence. The model member has the same bytes in both archives.

Within the worktree, the complete supplemental source experiment and all 48 outcome receipts are in `runs/first-attempt/corner-distilled-yaw/`. The original PiPER simulator uses DVIDIA Training base commit `e13ff91fe2466cf630fe49c0dd0993dfafdd8e0e` and the source overlay included in the base package.

[Development report](REPORT.md) · [Summary](summary.json) · [Registered cases](protocol.json) · [Robot-only FK check](geometry.json)
