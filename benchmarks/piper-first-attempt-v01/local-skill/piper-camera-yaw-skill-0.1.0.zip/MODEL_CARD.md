# Model card

**Version.** 0.1.0-yaw. The 194,832-byte CPU model uses the identical NumPy weights from the base camera-XY skill. SHA-256 `aa0e1cc395954099fae954a479aa703b6cc0062a10d2ac5bed9390b96ab45c00`.

**Scope.** Simulated PiPER with its pinned six-axis arm and stock parallel gripper, one upright 40 mm cube, and two destinations on a surveyed work surface. The trained weights interpolate across historical camera XY, destination and time. One geometric adapter reads initial upright block yaw and changes only the wrist reference. The first target remains identical. Measured joints bound each arm target step, and the native simulator preserves its actuator bounds and slew.

**Results.** With camera yaw, the model completed 24/24 independently scored simulated placements at −32° and +24°. The same model with its nominal wrist completed 16/24. Both logged zero critical-contact episodes. All eight gains came from the 60 g, friction 0.55 condition. Peak force per episode had a lower median, 0.709 N versus 0.881 N, and a higher observed maximum, 1.816 N versus 1.533 N.

**Limits.** The 24 development scenes use six prior development starting positions, two angles and two goals. The same fixed geometry and surveyed camera apply throughout. The skill does not update perception after initialization, check load retention, or recover a dropped block. Physical transfer is unverified. The task uses simulated sensing and authored simulator demonstrations.

[Development results](evidence/summary.json) · [Fixed protocol](evidence/protocol.json) · [Base evidence references](evidence/INDEX.md)
