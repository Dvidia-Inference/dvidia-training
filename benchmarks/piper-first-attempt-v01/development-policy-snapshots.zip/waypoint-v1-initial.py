"""Camera-initialized, encoder-controlled PiPER placement of one known rigid block.

The initial RGB-D estimate is historical. An aperture consistent with the block
is a gripper proxy: a mechanically jammed finger or a different object may
produce the same reading. All success judgments belong to the native scorer.
"""
import math

import numpy as np


_VERTICAL = np.array([0., 0., 1., 0.])
_CARRY = np.array([math.cos(5 * math.pi / 12), 0., math.sin(5 * math.pi / 12), 0.])
_CLEARANCE = np.array([0., 0., .10])
_MAX_JAW = .035


def _rotation(q):
    w, x, y, z = q
    return np.array([
        [1 - 2*(y*y + z*z), 2*(x*y - w*z), 2*(x*z + w*y)],
        [2*(x*y + w*z), 1 - 2*(x*x + z*z), 2*(y*z - w*x)],
        [2*(x*z - w*y), 2*(y*z + w*x), 1 - 2*(x*x + y*y)],
    ])


def _aligned(measured, desired):
    return abs(np.dot(measured, desired)) > math.cos(.12 / 2.)


def _cube_aperture(finger_positions):
    # Two separately measured, opposing 35-mm finger joints around a 40-mm cube.
    # Check each side, including sign; an average gap can mask unilateral contact.
    left, right = finger_positions
    return .014 <= left <= .026 and .014 <= -right <= .026


class WaypointPlacementPolicy:
    """Authored waypoints and DLS IK, with optional bounded encoder grip checks."""

    def __init__(self, kinematics, *, check_grip=True):
        self.kinematics = kinematics
        self.check_grip = check_grip
        self.phase = self.issued_phase = 'approach'
        self.phase_start_s = 0.
        self.grip_ticks = 0
        self.anchor = self.destination = self.held_offset = None
        self.refusal_reason = None

    def _advance(self, phase, now):
        self.phase = phase
        self.phase_start_s = now
        self.grip_ticks = 0

    def __call__(self, observation):
        now = observation['t_seconds']
        q = observation['joint_position_rad']
        tcp = np.asarray(observation['tcp_position_world_m'])
        measured_rotation = np.asarray(observation['tcp_quaternion_wxyz'])
        fingers = observation['gripper_joint_position_m']
        if self.anchor is None:
            self.anchor = np.array(observation['initial_object_position_world_m'], dtype=float)
            self.destination = np.array(observation['goal_position_world_m'], dtype=float)
            if any(v.shape != (3,) or not np.all(np.isfinite(v))
                   for v in (self.anchor, self.destination)):
                raise ValueError('A finite initial camera position and a known destination are required')
            # The task specifies a shared, level support surface and a rigid cube.
            # Use that known support height during approach and placement.
            self.anchor[2] = self.destination[2]

        phase = self.issued_phase = self.phase
        elapsed = now - self.phase_start_s
        grasp = self.anchor + [0., 0., .002]
        jaw = _MAX_JAW
        orientation = _VERTICAL
        if phase == 'approach':
            target, orientation = self.anchor + _CLEARANCE, _CARRY
            if np.linalg.norm(tcp - target) < .008 and _aligned(measured_rotation, orientation):
                self._advance('descend', now)
        elif phase == 'descend':
            target = grasp
            if np.linalg.norm(tcp - target) < .004 and _aligned(measured_rotation, orientation):
                self._advance('close', now)
        elif phase == 'close':
            target, jaw = grasp, 0.
            self.grip_ticks = self.grip_ticks + 1 if _cube_aperture(fingers) else 0
            if elapsed >= .72 and (not self.check_grip or self.grip_ticks >= 4):
                # Estimated offset, using the original camera measurement, known
                # support height and measured tool pose at the end of closure.
                self.held_offset = _rotation(measured_rotation).T @ (self.anchor - tcp)
                self._advance('lift', now)
            elif elapsed > 1.5:
                self.refusal_reason = 'aperture_inconsistent_with_cube'
                self._advance('refused', now)
        elif phase == 'lift':
            target, orientation, jaw = grasp + _CLEARANCE, _CARRY, 0.
            if np.linalg.norm(tcp - target) < .008:
                self._advance('transfer', now)
        elif phase == 'transfer':
            orientation, jaw = _CARRY, 0.
            target = self.destination - _rotation(orientation) @ self.held_offset + _CLEARANCE
            if np.linalg.norm(tcp - target) < .008:
                self._advance('place', now)
        elif phase == 'place':
            target, jaw = self.destination - _rotation(orientation) @ self.held_offset, 0.
            if np.linalg.norm(tcp - target) < .004:
                self._advance('seat', now)
        elif phase == 'seat':
            # Give the held block time to reach its known support plane before
            # issuing the open command. No contact or support flags are available.
            target, jaw = self.destination - _rotation(orientation) @ self.held_offset, 0.
            if elapsed >= .24:
                self._advance('release', now)
        elif phase == 'release':
            target = self.destination - _rotation(orientation) @ self.held_offset
            if elapsed >= .72 and (not self.check_grip or min(fingers[0], -fingers[1]) > .028):
                self._advance('retreat', now)
        elif phase in ('retreat', 'verify'):
            target, orientation = self.destination + [0., 0., .13], _CARRY
            if phase == 'retreat' and np.linalg.norm(tcp - target) < .008:
                self._advance('verify', now)
        elif phase == 'refused':
            # Refusal happens with the hand at the supported grasp pose.
            target = grasp
        else:
            raise RuntimeError(f'Unknown placement phase {phase}')
        return self.kinematics.pose_action(q, target, orientation, jaw)


def make_policy(controller, kinematics):
    if controller not in ('waypoint-v1', 'waypoint-timed'):
        raise ValueError(f'Unknown PiPER first-attempt policy {controller}')
    return WaypointPlacementPolicy(kinematics, check_grip=controller == 'waypoint-v1')
