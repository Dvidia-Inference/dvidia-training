"""Camera-initialized, encoder-controlled PiPER placement of one known rigid block.

The initial RGB-D estimate is historical. An aperture consistent with the block
is a gripper proxy: a mechanically jammed finger or a different object may
produce the same reading. All success judgments belong to the native scorer.
"""
import math

import numpy as np


_VERTICAL = np.array([0., 0., 1., 0.])
_CARRY = np.array([math.cos(5 * math.pi / 12), 0., math.sin(5 * math.pi / 12), 0.])
_CLEARANCE = np.array([0., 0., .10])
_MAX_JAW = .035


def _rotation(q):
    w, x, y, z = q
    return np.array([
        [1 - 2*(y*y + z*z), 2*(x*y - w*z), 2*(x*z + w*y)],
        [2*(x*y + w*z), 1 - 2*(x*x + z*z), 2*(y*z - w*x)],
        [2*(x*z - w*y), 2*(y*z + w*x), 1 - 2*(x*x + y*y)],
    ])


def _aligned(measured, desired):
    return abs(np.dot(measured, desired)) > math.cos(.12 / 2.)


def _cube_aperture(finger_positions, half_span=.020):
    # Two separately measured, opposing 35-mm finger joints around a 40-mm cube.
    # Check each side, including sign; an average gap can mask unilateral contact.
    left, right = finger_positions
    return abs(left - half_span) <= .006 and abs(-right - half_span) <= .006


class WaypointPlacementPolicy:
    """Authored waypoints and DLS IK, with optional bounded encoder grip checks."""

    def __init__(self, kinematics, *, check_grip=True, corner_grip=False, profiled=False, planar_seat=False, fast=False):
        self.kinematics = kinematics
        self.check_grip = check_grip
        self.corner_grip = corner_grip
        self.profiled = profiled
        self.planar_seat = planar_seat
        self.fast = fast
        self.approach_joints = self.travel_origin = None
        self.lost_ticks = 0
        self.half_span = .020 * (math.sqrt(2.) if corner_grip else 1.)
        self.vertical, self.carry = _VERTICAL, _CARRY
        if corner_grip:
            # A 45-degree twist around the tool axis presents opposite corners.
            # The increased span induces more preload in the stock position servo.
            c, s = math.cos(math.pi / 8.), math.sin(math.pi / 8.)
            def twist(q):
                w, x, y, z = q
                return np.array([w*c - z*s, x*c + y*s, y*c - x*s, z*c + w*s])
            carry = _CARRY
            if profiled:
                pitch = math.radians(160.)
                carry = np.array([math.cos(pitch / 2.), 0., math.sin(pitch / 2.), 0.])
            self.vertical, self.carry = twist(_VERTICAL), twist(carry)
        self.seating_orientation = self.vertical
        if fast:
            mild_tilt = .85 * self.vertical + .15 * self.carry
            self.seating_orientation = mild_tilt / np.linalg.norm(mild_tilt)
        self.phase = self.issued_phase = 'approach'
        self.phase_start_s = 0.
        self.grip_ticks = 0
        self.anchor = self.destination = self.held_offset = None
        self.refusal_reason = None

    def _advance(self, phase, now):
        self.phase = phase
        self.phase_start_s = now
        self.grip_ticks = 0
        self.travel_origin = None

    def _approach_action(self, q, target, orientation, jaw):
        # Solve the pregrasp pose in the detached robot-only kinematic model.
        # An interpolated joint command stays within the stock 0.06-rad
        # encoder-relative step bound; the native servo also limits its rate.
        if self.approach_joints is None:
            planned = np.asarray(q)
            for _ in range(120):
                updated = np.asarray(self.kinematics.pose_action(planned, target, orientation, jaw)['joint_targets_rad'])
                if np.max(np.abs(updated - planned)) < .00005:
                    break
                planned = updated
            self.approach_joints = planned
        delta = self.approach_joints - q
        maximum = np.max(np.abs(delta))
        if maximum > .03:
            command = np.asarray(q) + min(1., .06 / maximum) * delta
            return {'joint_targets_rad': command.tolist(), 'gripper_position_m': jaw}
        return self.kinematics.pose_action(q, target, orientation, jaw)

    def _travel(self, observed_tcp, destination, elapsed, duration):
        if self.travel_origin is None:
            self.travel_origin = observed_tcp.copy()
        t = np.clip(elapsed / duration, 0., 1.)
        alpha = (t**3 * (10. + t * (-15. + 6. * t)) if self.fast
                 else t * t * (3. - 2. * t))
        return self.travel_origin + (destination - self.travel_origin) * alpha, alpha

    def __call__(self, observation):
        now = observation['t_seconds']
        q = observation['joint_position_rad']
        tcp = np.asarray(observation['tcp_position_world_m'])
        measured_rotation = np.asarray(observation['tcp_quaternion_wxyz'])
        fingers = observation['gripper_joint_position_m']
        if self.anchor is None:
            self.anchor = np.array(observation['initial_object_position_world_m'], dtype=float)
            self.destination = np.array(observation['goal_position_world_m'], dtype=float)
            if any(v.shape != (3,) or not np.all(np.isfinite(v))
                   for v in (self.anchor, self.destination)):
                raise ValueError('A finite initial camera position and a known destination are required')
            # The task specifies a shared, level support surface and a rigid cube.
            # Use that known support height during approach and placement.
            self.anchor[2] = self.destination[2]

        phase = self.issued_phase = self.phase
        elapsed = now - self.phase_start_s
        grasp = self.anchor + [0., 0., .002]
        jaw = _MAX_JAW
        orientation = self.vertical
        if phase == 'approach':
            target, orientation = self.anchor + _CLEARANCE, self.carry
            if self.profiled:
                target, orientation = self.anchor + [0., 0., .034], self.vertical
                if self.fast:
                    target = self.anchor + [0., 0., .023]
                    near_vertical = .72*self.vertical + .28*self.carry
                    orientation = near_vertical / np.linalg.norm(near_vertical)
            if np.linalg.norm(tcp - target) < .008 and _aligned(measured_rotation, orientation):
                self._advance('descend', now)
        elif phase == 'descend':
            target = grasp
            if np.linalg.norm(tcp - target) < .004 and _aligned(measured_rotation, orientation):
                self._advance('close', now)
        elif phase == 'close':
            target, jaw = grasp, 0.
            self.grip_ticks = self.grip_ticks + 1 if _cube_aperture(fingers, self.half_span) else 0
            if elapsed >= .72 and (not self.check_grip or self.grip_ticks >= 4):
                # Estimated offset, using the original camera measurement, known
                # support height and measured tool pose at the end of closure.
                self.held_offset = _rotation(measured_rotation).T @ (self.anchor - tcp)
                self._advance('probe' if self.corner_grip else 'lift', now)
            elif elapsed > 1.5:
                self.refusal_reason = 'aperture_inconsistent_with_cube'
                self._advance('refused', now)
        elif phase == 'probe':
            target = grasp + [0., 0., min(.008, .025 * elapsed)]
            jaw = 0.
            if elapsed >= .6 and tcp[2] > grasp[2] + .005:
                if self.check_grip and not _cube_aperture(fingers, self.half_span):
                    self.refusal_reason = 'aperture_lost_during_test_lift'
                    self._advance('refused', now)
                else:
                    self._advance('lift', now)
        elif phase == 'lift':
            target, orientation, jaw = grasp + _CLEARANCE, self.carry, 0.
            if self.profiled:
                lift_duration = 1.45 if self.fast else 1.8
                target, alpha = self._travel(tcp, target, elapsed, lift_duration)
                orientation = (1. - alpha) * self.vertical + alpha * self.carry
                orientation /= np.linalg.norm(orientation)
            if (not self.profiled or elapsed >= lift_duration) and np.linalg.norm(tcp - target) < .008:
                self._advance('transfer', now)
        elif phase == 'transfer':
            orientation, jaw = self.carry, 0.
            target = self.destination - _rotation(orientation) @ self.held_offset + _CLEARANCE
            if self.profiled:
                transfer_duration = 1.42 if self.fast else 1.6
                target, _ = self._travel(tcp, target, elapsed, transfer_duration)
            if (not self.profiled or elapsed >= transfer_duration) and np.linalg.norm(tcp - target) < .008:
                self._advance('place', now)
        elif phase == 'place':
            orientation = self.seating_orientation
            target, jaw = self.destination - _rotation(orientation) @ self.held_offset, 0.
            if self.profiled:
                target, alpha = self._travel(tcp, target, elapsed, 1.3)
                orientation = (1. - alpha) * self.carry + alpha * self.seating_orientation
                orientation /= np.linalg.norm(orientation)
            error = tcp - target
            # A level support plane constrains height differently from XY. The
            # stock wrist may retain spare lateral error near full extension.
            arrived = (np.linalg.norm(error[:2]) < .010 and abs(error[2]) < .0025
                       if self.planar_seat else np.linalg.norm(error) < .004)
            if (not self.profiled or elapsed >= 1.3) and arrived:
                self._advance('seat', now)
        elif phase == 'seat':
            orientation = self.seating_orientation
            # Give the held block time to reach its known support plane before
            # issuing the open command. No contact or support flags are available.
            target, jaw = self.destination - _rotation(orientation) @ self.held_offset, 0.
            if elapsed >= (.36 if self.planar_seat else .24):
                self._advance('release', now)
        elif phase == 'release':
            orientation = self.seating_orientation
            target = self.destination - _rotation(orientation) @ self.held_offset
            if elapsed >= .72 and (not self.check_grip or min(fingers[0], -fingers[1]) > .028):
                self._advance('retreat', now)
        elif phase in ('retreat', 'verify'):
            target, orientation = self.destination + [0., 0., .13], self.carry
            if phase == 'retreat' and np.linalg.norm(tcp - target) < .008:
                self._advance('verify', now)
        elif phase == 'refused':
            # Refusal happens at the initial grasp or during its 8-mm test.
            target = grasp
        elif phase == 'lost_grip':
            return {'joint_targets_rad': list(q), 'gripper_position_m': 0.}
        else:
            raise RuntimeError(f'Unknown placement phase {phase}')
        if self.profiled and self.check_grip and phase in ('lift', 'transfer', 'place'):
            self.lost_ticks = 0 if _cube_aperture(fingers, self.half_span) else self.lost_ticks + 1
            if self.lost_ticks >= 4:
                self.refusal_reason = 'aperture_lost_in_motion'
                self._advance('lost_grip', now)
                return {'joint_targets_rad': list(q), 'gripper_position_m': 0.}
        if self.profiled and phase == 'approach':
            return self._approach_action(q, target, orientation, jaw)
        return self.kinematics.pose_action(q, target, orientation, jaw)


def make_policy(controller, kinematics):
    if controller not in ('waypoint-v1', 'waypoint-timed', 'corner-v2', 'corner-v2-timed', 'corner-v3', 'corner-v3-timed', 'corner-v4', 'corner-v4-timed', 'corner-v5', 'corner-v5-timed'):
        raise ValueError(f'Unknown PiPER first-attempt policy {controller}')
    return WaypointPlacementPolicy(kinematics, check_grip=controller in ('waypoint-v1', 'corner-v2', 'corner-v3', 'corner-v4', 'corner-v5'),
                                   corner_grip=controller.startswith('corner-'), profiled=controller.startswith(('corner-v3', 'corner-v4', 'corner-v5')),
                                   planar_seat=controller.startswith(('corner-v4', 'corner-v5')),
                                   fast=controller.startswith('corner-v5'))
